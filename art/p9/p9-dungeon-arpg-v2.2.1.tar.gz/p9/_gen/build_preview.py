from PIL import Image, ImageDraw
import json
A="/home/zero/Documents/lunego-workspace/games/p9/assets/"
man=json.load(open(A+"manifest.json"))
BG=(26,26,34); FG=(232,236,244); ACC=(242,193,78)
W=1180; pad=16
rows=[]
def label(d,xy,text,dh=14):
    d.text((xy[0],xy[1]),text,fill=FG)

# plan rows: player(3x), enemies(3x), items(4x)+icons(6x), tiles(3x), ui(2x)
player=Image.open(A+"sprites/player.png")
enem=[Image.open(A+f"sprites/enemies/{n}.png") for n in ("slime","brute","caster","charger","bomber","elite","boss")]
proj=[Image.open(A+f"sprites/projectiles/{n}.png") for n in ("arrow","bolt","fire")]
items=Image.open(A+"sprites/items/items.png"); icons=Image.open(A+"sprites/ui/icons.png")
tiles=[Image.open(A+f"tiles/{n}.png") for n in ("floor_stone","floor_stone_a","floor_stone_b","floor_stone_c",
       "floor_dirt","wall_stone","wall_top","door_closed","door_open","stairs_down","crate","barrel","pillar","torch")]
panel=Image.open(A+"ui/panel.png"); btn=Image.open(A+"ui/button.png")

parts=[]
def scale(im,k): return im.resize((im.size[0]*k,im.size[1]*k),Image.NEAREST)
parts.append(("PLAYER 32x32  rows: down/left/right/up  cols: idle(2) walk(4) attack(3) cast(3) hurt(1) death(5)", scale(player,3)))
parts.append(("ENEMIES 32/40/64 + PROJECTILES 16", None))
parts.append(("ITEMS 24x24", scale(items,4)))
parts.append(("UI ICONS 16x16 + 9-SLICE 32x32 border 8", None))
parts.append(("DUNGEON TILESET 32x32", None))

# measure height
H=8+sum((im.size[1]+26 if im else 0) for _,im in parts)
H+= 40+ 120+120+90+140
canvas=Image.new("RGB",(W,H),BG); d=ImageDraw.Draw(canvas)
y=8
# player
txt,im=parts[0]; d.text((pad,y),txt,fill=ACC); y+=16
canvas.paste(im,(pad,y),im); y+=im.size[1]+10
# enemies
d.text((pad,y),parts[1][0],fill=ACC); y+=16
x=pad; rowh=0
for i,e in enumerate(enem):
    if i==4: x=pad; y+=rowh+6; rowh=0
    s=scale(e,2); canvas.paste(s,(x,y),s); x+=s.size[0]+8; rowh=max(rowh,s.size[1])
y+=rowh+6; x=pad
for p in proj:
    s=scale(p,3); canvas.paste(s,(x,y),s); x+=s.size[0]+10
y+=max(scale(p,3).size[1] for p in proj)+10
# items
d.text((pad,y),parts[2][0],fill=ACC); y+=16
s=scale(items,3); canvas.paste(s,(pad,y),s); y+=s.size[1]+6
s=scale(icons,3); canvas.paste(s,(pad,y),s)
y+=s.size[1]+16
# ui
d.text((pad,y),parts[3][0],fill=ACC); y+=16
def nine(im,w,h,b=8):
    S=32; out=Image.new("RGBA",(w,h),(0,0,0,0)); seg=[0,b,S-b,S]; dst=[0,b,w-b,w]
    for j in range(3):
        for i in range(3):
            p=im.crop((seg[i],seg[j],seg[i+1],seg[j+1])); tw,th=dst[i+1]-dst[i],dst[j+1]-dst[j]
            if tw>0 and th>0: out.paste(p.resize((tw,th),Image.NEAREST),(dst[i],dst[j]))
    return out
canvas.paste(nine(panel,220,80).convert("RGB"),(pad,y)); canvas.paste(nine(btn,90,28).convert("RGB"),(pad+240,y))
y+=92
# tiles
d.text((pad,y),parts[4][0],fill=ACC); y+=16
x=pad
for t in tiles:
    s=scale(t,2); canvas.paste(s.convert("RGB"),(x,y)); x+=s.size[0]+2
y+=64+8
# tiled sample
floor=[Image.open(A+f"tiles/floor_stone_{c}.png").convert("RGB") for c in "abc"]
sample=Image.new("RGB",(6*32,4*32))
for yy in range(4):
    for xx in range(6):
        sample.paste(floor[(xx*7+yy*3)%3] if yy else Image.open(A+"tiles/wall_stone.png").convert("RGB"),(xx*32,yy*32))
s=scale(sample,3); canvas.paste(s,(pad,y))
y+=s.size[1]+8
d.text((pad,y),"floor variants tiled 6x4 + wall row (seamless)",fill=FG)
canvas=canvas.crop((0,0,W,y+24))
import numpy as np
arr=np.array(canvas); nz=np.where(((arr!=np.array(BG)).any(axis=2)) & (arr.sum(axis=2)>40))[0]
canvas=canvas.crop((0,0,W,int(nz.max())+10))
canvas.save(A+"preview.png")
print("preview", canvas.size)
