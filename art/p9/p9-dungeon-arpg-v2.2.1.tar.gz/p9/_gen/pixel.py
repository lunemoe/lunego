"""Shared pixel pipeline: alpha-aware frame splitting, palette quantization, packing."""
from PIL import Image
import numpy as np

PALETTE = [
 (16,16,24),(26,26,38),(46,47,61),(74,76,94),(107,110,130),(154,157,178),(232,236,244),
 (232,180,140),(184,123,92),(242,193,78),(176,124,42),(232,116,58),(200,57,43),(122,26,28),
 (47,111,184),(99,166,232),(28,46,77),(107,63,160),(169,107,220),(79,214,232),
 (79,166,74),(143,208,90),(42,102,56),(138,90,51),(78,50,32),(247,224,138),(232,107,154),(216,203,168),
]

def load_rgba(path):
    im = Image.open(path).convert("RGBA")
    a = np.array(im).astype(np.int16)
    # binarize alpha, keep rgb
    a[...,3] = np.where(a[...,3] >= 110, 255, 0)
    return a

def split_frames(arr, expected):
    """Split a strip into frames using empty alpha columns; falls back to equal slices."""
    mask = arr[...,3] > 0
    cols = mask.any(axis=0)
    runs, start = [], None
    for x, v in enumerate(cols):
        if v and start is None: start = x
        if not v and start is not None: runs.append((start,x)); start=None
    if start is not None: runs.append((start,len(cols)))
    # merge runs separated by <6px, drop runs narrower than 8px or with tiny area
    merged=[]
    for r in runs:
        if merged and r[0]-merged[-1][1] < max(6, arr.shape[1]//120): merged[-1]=(merged[-1][0], r[1])
        else: merged.append(list(r) if False else (r[0],r[1]))
    merged=[r for r in merged if r[1]-r[0] > 8 and mask[:, r[0]:r[1]].sum() > 200]
    if merged:
        widths=sorted(r[1]-r[0] for r in merged); med=widths[len(widths)//2]
        merged=[r for r in merged if (r[1]-r[0]) >= 0.5*med]
    if len(merged) != expected:
        return None, merged
    out=[]
    for x0,x1 in merged:
        sub = arr[:, x0:x1]
        ys = np.where(sub[...,3].any(axis=1))[0]
        out.append(sub[ys.min():ys.max()+1])
    return out, merged

def pal_image():
    p = Image.new("P", (1,1))
    flat=[]
    for c in PALETTE: flat += list(c)
    flat += [0,0,0]*(256-len(PALETTE))
    p.putpalette(flat)
    return p

_PAL = pal_image()

def quantize(rgba_img, alpha_thresh=110):
    """Map RGB onto the shared palette, binary alpha, no dither."""
    rgb = rgba_img.convert("RGB").quantize(palette=_PAL, dither=Image.Dither.NONE).convert("RGB")
    a = rgba_img.getchannel("A").point(lambda v: 255 if v > alpha_thresh else 0)
    out = rgb.convert("RGBA"); out.putalpha(a)
    return out

def fit_frame(frame_rgba, fw, fh, pad_x=2, pad_y=2, scale_hint=None):
    """Scale a cropped frame into fw x fh with bottom-center anchor and pad."""
    w,h = frame_rgba.size
    maxw, maxh = fw-2*pad_x, fh-pad_y-2
    s = min(maxw/w, maxh/h) if not scale_hint else scale_hint
    nw, nh = max(1,round(w*s)), max(1,round(h*s))
    small = frame_rgba.resize((nw,nh), Image.LANCZOS)
    canvas = Image.new("RGBA",(fw,fh),(0,0,0,0))
    canvas.paste(small, ((fw-nw)//2, fh-pad_y-nh), small)
    q = quantize(canvas)
    return q

def add_outline(img, color=(16,16,24)):
    """Add a 1px dark outline outside the silhouette."""
    import numpy as np
    a = np.array(img)
    alpha = a[...,3] > 0
    grown = alpha.copy()
    for dy,dx in ((1,0),(-1,0),(0,1),(0,-1)):
        grown |= np.roll(np.roll(alpha,dy,0),dx,1)
    edges = grown & ~alpha
    a[edges] = (*color,255)
    return Image.fromarray(a)

def split_strip(arr, expected):
    """Robust frame extraction: detected gaps, else equal division of the content box."""
    mask = arr[...,3] > 0
    ys = np.where(mask.any(axis=1))[0]; xs = np.where(mask.any(axis=0))[0]
    if len(ys)==0 or len(xs)==0: return []
    y0,y1,x0,x1 = ys.min(), ys.max()+1, xs.min(), xs.max()+1
    frames, merged = split_frames(arr, expected)
    if frames: return frames
    if expected == 1:
        return [arr[y0:y1, x0:x1]]
    step = (x1-x0)/expected
    out=[]
    for i in range(expected):
        a=int(round(x0+i*step)); b=int(round(x0+(i+1)*step))
        sub = arr[y0:y1, a:b]
        m = sub[...,3] > 0
        if not m.any(): return []
        sy = np.where(m.any(axis=1))[0]
        out.append(sub[sy.min():sy.max()+1])
    return out

def frames_to_img(frames):
    return [Image.fromarray(f.astype(np.uint8), "RGBA") for f in frames]

def cleanup(img):
    """Remove 1px alpha specks, fill 1px holes inside the silhouette, drop isolated color noise."""
    a = np.array(img)
    alpha = a[...,3] > 0
    nb = np.zeros(alpha.shape, np.int16)
    for dy,dx in ((1,0),(-1,0),(0,1),(0,-1)):
        nb += np.roll(np.roll(alpha,dy,0),dx,1).astype(np.int16)
    alpha = alpha & (nb >= 2)          # drop specks
    alpha = alpha | (nb >= 3)          # fill 1px holes
    # collapse isolated odd colors: replace a pixel by its 3+ agreeing neighbour colour
    out = a.copy(); out[...,3] = np.where(alpha,255,0)
    rgb = out[...,:3]
    for y in range(1,a.shape[0]-1):
        for x in range(1,a.shape[1]-1):
            if not alpha[y,x]: continue
            neigh = []
            for dy,dx in ((1,0),(-1,0),(0,1),(0,-1)):
                if alpha[y+dy,x+dx]: neigh.append(tuple(rgb[y+dy,x+dx]))
            if len(neigh)>=3 and neigh.count(tuple(rgb[y,x]))==0:
                best=max(set(neigh), key=neigh.count)
                if neigh.count(best)>=3: rgb[y,x]=best
    return Image.fromarray(out)
