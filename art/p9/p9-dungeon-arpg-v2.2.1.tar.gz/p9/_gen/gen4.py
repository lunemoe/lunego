import subprocess, concurrent.futures as cf, os
BASE=("simple chunky retro pixel art sprite, LOW detail, big flat colour shapes, very few colours, "
      "strong readable silhouette, minimal internal detail, 32 pixel tall character, thick dark outline, no text")
P={
 "elite_walk_simple": ("sprite sheet, ONE elite knight creature, exactly 4 frame walk animation in a single horizontal row, "
   "black plate armor with a few glowing violet runes, small horned helmet, oversized pauldrons, simple shapes, "
   "facing the camera in top-down 3/4 view, identical design and scale in every frame", "wide"),
 "brute_walk_simple": ("sprite sheet, ONE brute monster, exactly 4 frame heavy walk animation in a single horizontal row, "
   "big red-skinned muscular ogre with tiny horns and a huge simple axe, simple shapes, "
   "facing the camera in top-down 3/4 view, identical design and scale in every frame", "wide"),
 "charger_walk_simple": ("sprite sheet, ONE beast creature, exactly 4 frame run animation in a single horizontal row, "
   "brown armored boar with white tusks charging to the right, simple shapes, side profile, "
   "identical design and scale in every frame", "wide"),
}
def run(kv):
    n,(p,asp)=kv; f=f"raw/{n}.png"
    if os.path.exists(f) and os.path.getsize(f)>1000: return n,"cached"
    r=subprocess.run(["gpt-image",p+BASE,"--background","transparent","-a",asp,"-o",f,"-q"],capture_output=True,text=True)
    return n,"ok" if r.returncode==0 and os.path.exists(f) else "FAIL "+r.stderr[-200:]
with cf.ThreadPoolExecutor(3) as ex:
    for n,s in ex.map(run,P.items()): print(n,s,flush=True)
