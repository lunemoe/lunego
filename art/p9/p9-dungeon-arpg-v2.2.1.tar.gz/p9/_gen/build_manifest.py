import json, os, subprocess
from PIL import Image
A="../"; TODAY="2026-11-02"
PALETTE_HEX=["#101018","#1a1a26","#2e2f3d","#4a4c5e","#6b6e82","#9a9db2","#e8ecf4","#e8b48c","#b87b5c",
             "#f2c14e","#b07c2a","#e8743a","#c8392b","#7a1a1c","#2f6fb8","#63a6e8","#1c2e4d","#6b3fa0",
             "#a96bdc","#4fd6e8","#4fa64a","#8fd05a","#2a6636","#8a5a33","#4e3220","#f7e08a","#e86b9a","#d8cba8"]

def sz(p):
    im=Image.open(p); return im.size

AI=dict(kind="ai-generated", tool="gpt-image-2.5 (magpie gateway, local)",
        license="CC0-1.0", author="generated for p9 (this repo)",
        pipeline="gpt-image -> alpha crop -> LANCZOS downscale -> shared 28-colour palette quantise -> 1px cleanup")
def ai(prompt): return {**AI, "prompt": prompt}

AS=[]

def add(id, file, w, h, cols, rows, fps=None, anims=None, anchor="bottom-center",
        source=None, tags=None, note=None, opaque=False):
    AS.append({"id":id,"file":file,"type":"sprite","frameWidth":w,"frameHeight":h,
               "columns":cols,"rows":rows,"frames":cols*rows,"fps":fps,
               "animations":anims or [],"anchor":anchor,"transparent":not opaque,
               "source":source,"tags":tags or [],"notes":note})

P_WALK=("player idle / walk / attack / cast / hurt / death, one sheet, rows = facing")
add("player", "sprites/player.png",32,32,18,4,8,
    [{"name":"idle","columns":[0,1],"frames":2,"loop":True},
     {"name":"walk","columns":[2,5],"frames":4,"loop":True},
     {"name":"attack","columns":[6,8],"frames":3,"loop":False,"fps":10},
     {"name":"cast","columns":[9,11],"frames":3,"loop":False,"fps":10},
     {"name":"hurt","columns":[12,12],"frames":1,"loop":False},
     {"name":"death","columns":[13,17],"frames":5,"loop":False,"fps":8}],
    source=ai("hero knight in blue tabard with sword and round shield, 4-frame walk / 3-frame attack / "
              "3-frame spell cast / death strips per facing (front, back, right profile), restyled to low-res pixel art"),
    tags=["player","knight","4-direction"],
    note="rows: 0=down(face) 1=left 2=right 3=up(back); animations are column ranges; "
         "idle frame 2 is a 1px breathing bob derived from walk frame 0; hurt is a 2px recoil derived from walk frame 0; "
         "up-facing death reuses the front death frames")

for eid,w,h,fps,note,prompt in [
 ("boss",64,64,6,"single 4-frame idle/breathing strip","enormous horned demon lord with crown, flaming cleaver"),
 ("elite",40,40,7,"single 4-frame walk strip","black plate elite knight with violet runes"),
]:
    add(eid, f"sprites/enemies/{eid}.png",w,h,4,1,fps,[{"name":"walk","columns":[0,3],"frames":4,"loop":True}],
        source=ai(prompt+" — 4-frame walk strip, restyled to low-res pixel art"),tags=["enemy",eid],note=note)

for eid,tag,prompt in [
 ("slime","melee-grunt","translucent lime slime blob with two dark eyes, 4-frame bounce"),
 ("brute","melee-heavy","red-skinned brute ogre with axe, 4-frame heavy walk"),
 ("caster","ranged","hooded purple cultist mage with glowing cyan orb, 4-frame float"),
 ("charger","melee-charger","armored tusked boar charging right, 4-frame gallop"),
 ("bomber","self-destruct","round bomb creature with lit fuse, 4-frame waddle"),
]:
    add(eid, f"sprites/enemies/{eid}.png",32,32,4,1,8,[{"name":"walk","columns":[0,3],"frames":4,"loop":True}],
        source=ai(prompt+" — 4-frame strip, restyled to low-res pixel art"),tags=["enemy",tag])

for pid,tag in [("arrow","physical"),("bolt","magic"),("fire","fire")]:
    add(pid, f"sprites/projectiles/{pid}.png",16,16,1,1,None,[{"name":"default","columns":[0,0],"frames":1}],
        source=ai(f"{pid} projectile flying right, single frame, tiny crisp pixel art"),tags=["projectile",tag])

ITEMS={"coin":"gold coin","gem":"blue sapphire gem","chest":"closed treasure chest","chest_open":"open chest with gold",
       "potion":"red healing potion","sword":"steel sword","armor":"steel chest plate","amulet":"gold amulet with violet gem",
       "runestone":"carved rune tablet"}
for k,desc in ITEMS.items():
    add(f"item_{k}", f"sprites/items/{k}.png",24,24,1,1,None,[{"name":"default","columns":[0,0],"frames":1}],
        source=ai(f"{desc} inventory icon, pixel art"),tags=["item","icon"])
add("items_atlas","sprites/items/items.png",24,24,9,1,None,[],
    source=ai("same 9 item icons as one row atlas"),tags=["atlas","item"],
    note="column order: coin, gem, chest, chest_open, potion, sword, armor, amulet, runestone")

ICONS=["heart","sword","coin","gem","skull","star","bag","helmet","book","gear","shield"]
add("ui_icons","sprites/ui/icons.png",16,16,11,1,None,[],
    source=ai("UI icon row: heart, sword, coin, gem, skull, star, backpack, helmet portrait, spell book, gear, shield"),
    tags=["ui","icon"],note="column order: "+", ".join(ICONS))

TILES=[("floor_stone",True),("floor_stone_a",True),("floor_stone_b",True),("floor_stone_c",True),
       ("floor_dirt",True),("wall_stone",True),("wall_top",True),("door_closed",True),("door_open",True),
       ("stairs_down",True),("crate",False),("barrel",False),("pillar",False),("torch",False)]
PROC={"kind":"procedural","tool":"tools-less python/PIL generator (assets/_gen/tiles_proc.py, tiles_floor3.py)",
      "license":"CC0-1.0","author":"written for p9 (this repo)"}
for name,opaque in TILES:
    add(f"tile_{name}", f"tiles/{name}.png",32,32,1,2 if name=="torch" else 1,None,
        [{"name":"flicker","columns":[0,0],"frames":2,"loop":True,"fps":6}] if name=="torch" else [],
        source={**PROC,"note":"toroidal Voronoi cobbles for floors; deterministic brick/wood/stone drawing for the rest"},
        tags=["tile","prop" if not opaque else "tile"],opaque=opaque,
        note="2 vertical frames (0,1) for torch flicker" if name=="torch" else None)
add("tileset_atlas","tiles/tileset.png",32,32,len(TILES),1,None,[],source=PROC,tags=["atlas","tile"],
    note="column order: "+", ".join(t[0] for t in TILES))

for name,cols in (("panel",9),("panel_blue",9),("button",9)):
    AS.append({"id":f"ui_{name}","file":f"ui/{name}.png","type":"nine-slice","frameWidth":32,"frameHeight":32,
               "columns":1,"rows":1,"frames":1,"fps":None,"animations":[],"anchor":"top-left",
               "transparent":True,"nineSlice":{"border":8,"cols":cols},
               "source":{**PROC,"note":"32x32 nine-slice source, border 8, stretched with nearest-neighbour"},
               "tags":["ui","nine-slice"],"notes":"corners 8x8 are never stretched"})

AUDIO=[
 ("hit","impact","General Sounds/Impacts/sfx_sounds_impact1.wav"),
 ("slash","sword swing","Weapons/Melee/sfx_wpn_sword1.wav"),
 ("shoot","projectile shot","Weapons/Single Shot Sounds/sfx_weapon_singleshot2.wav"),
 ("cast","spell cast","General Sounds/Positive Sounds/sfx_sounds_powerup3.wav"),
 ("hurt","player hurt","General Sounds/Simple Damage Sounds/sfx_damage_hit2.wav"),
 ("death","death scream","Death Screams/Human/sfx_deathscream_human3.wav"),
 ("pickup","coin pickup","General Sounds/Coins/sfx_coin_single1.wav"),
 ("levelup","level up fanfare","General Sounds/Fanfares/sfx_sounds_fanfare1.wav"),
 ("button","UI button","General Sounds/Menu Sounds/sfx_menu_select1.wav"),
 ("door_open","dungeon door","Movement/Opening Doors/sfx_movement_dooropen1.wav"),
 ("chest_open","chest open","General Sounds/Interactions/sfx_sounds_interaction4.wav"),
 ("boss_roar","boss roar (pitched-down explosion derivative)","Explosions/Long/sfx_exp_long1.wav"),
]
def dur(p):
    r=subprocess.run(["ffprobe","-v","error","-show_entries","format=duration","-of","csv=p=0",p],capture_output=True,text=True)
    return round(float(r.stdout.strip()),3)

aud=[]
for name,desc,orig in AUDIO:
    f=f"audio/{name}.ogg"
    aud.append({"id":f"sfx_{name}","file":f,"type":"audio","description":desc,
                "duration":dur(A+f),"format":"ogg/vorbis mono",
                "source":{"kind":"download","pack":"The Essential Retro Video Game Sound Effects Collection [512 sounds]",
                          "author":"Juhani Junkala (SubspaceAudio)","license":"CC0-1.0",
                          "url":"https://opengameart.org/content/512-sound-effects-8-bit-style",
                          "originalFile":orig,
                          "processing":"converted to mono ogg (q4); boss_roar additionally pitch-shifted down and re-timed with ffmpeg"}})

# verify every sprite file exists and dimensions match
for a in AS:
    p=A+"/"+a["file"]
    assert os.path.exists(p), p
    w,h=sz(p)
    assert (w,h)==(a["frameWidth"]*a["columns"], a["frameHeight"]*a["rows"]), (p,w,h)

man={"pack":"p9-dungeon-arpg","version":"1.0.0","created":TODAY,
     "description":"Hero Siege style top-down pixel ARPG asset pack: player with 4 facings, 7 enemy types incl. boss, dungeon tileset, item/UI icons, 9-slice UI, 12 CC0 SFX.",
     "virtualResolution":[480,270],"pixelScale":"integer only (2x recommended); no filtering",
     "palette":{"colors":PALETTE_HEX,"note":"characters and icons quantised to these 28 colours; procedural tiles use shades of the same hues"},
     "licenses":{"aiArt":"CC0-1.0 (generated for this repo, no third-party input images)","tiles":"CC0-1.0","audio":"CC0-1.0"},
     "layoutConvention":{"player":"rows=[down,left,right,up]","enemies":"single row, 4 walk frames",
                         "anchor":"bottom-center for entities (feet), top-left for tiles/UI"},
     "assets":AS,"audio":aud}
json.dump(man,open(A+"manifest.json","w"),indent=2,ensure_ascii=False)
print("manifest:",len(AS),"assets,",len(aud),"audio")
