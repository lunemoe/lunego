import sys; sys.path.insert(0,'.')
import pixel, numpy as np
from PIL import Image

DIR="../sprites/enemies"
JOBS=[  # key, out, frames, size, body_h
 ("slime_restyle","slime",4,32,26),
 ("caster_restyle","caster",4,32,26),
 ("bomber_restyle","bomber",4,32,24),
 ("brute_restyle","brute",4,32,26),
 ("charger_restyle","charger",4,32,24),
 ("elite_restyle","elite",4,40,34),
 ("boss_restyle","boss",4,64,56),
]
for key,name,n,SZ,bh in JOBS:
    fr=pixel.frames_to_img(pixel.split_strip(pixel.load_rgba(f"raw/{key}.png"),n))
    assert len(fr)==n,(key,len(fr))
    mw=np.median([i.size[0] for i in fr]); mh=np.median([i.size[1] for i in fr])
    s=min(bh/mh,(SZ-4)/mw)
    sh=Image.new("RGBA",(n*SZ,SZ),(0,0,0,0))
    for i,im in enumerate(fr):
        w,h=im.size; k=min(s,(SZ-4)/w,(SZ-4)/h)
        nw,nh=max(1,round(w*k)),max(1,round(h*k))
        c=Image.new("RGBA",(SZ,SZ),(0,0,0,0))
        c.paste(im.resize((nw,nh),Image.LANCZOS),((SZ-nw)//2,SZ-2-nh))
        sh.paste(pixel.cleanup(pixel.quantize(c)),(i*SZ,0))
    sh.save(f"{DIR}/{name}.png")
    print(f"{DIR}/{name}.png",sh.size,"scale",round(s,4))
