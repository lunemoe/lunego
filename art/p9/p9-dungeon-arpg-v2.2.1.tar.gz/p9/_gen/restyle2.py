import subprocess, concurrent.futures as cf, os
STYLE = ("redraw this exact sprite sheet as clean low resolution pixel art, same number of frames in one horizontal row, "
         "same character design and same poses, only flat colours, hard pixel edges, no anti-aliasing, no blur, "
         "high contrast readable silhouette, thick dark outline, transparent background")
JOBS = {
 "pw_up":("raw/player_walk_up.png","raw/pw_up_restyle.png"),
 "pa_down":("raw/player_attack_down.png","raw/pa_down_restyle.png"),
 "pa_up":("raw/player_attack_up.png","raw/pa_up_restyle.png"),
 "pa_side":("raw/player_attack_side.png","raw/pa_side_restyle.png"),
 "pc_down":("raw/player_cast_down.png","raw/pc_down_restyle.png"),
 "pc_up":("raw/player_cast_up.png","raw/pc_up_restyle.png"),
 "pc_side":("raw/player_cast_side.png","raw/pc_side_restyle.png"),
 "pd_down":("raw/player_death_down.png","raw/pd_down_restyle.png"),
 "pd_side":("raw/player_death_side.png","raw/pd_side_restyle.png"),
 "slime":("raw/slime_walk.png","raw/slime_restyle.png"),
 "caster":("raw/ranged_walk.png","raw/caster_restyle.png"),
 "bomber":("raw/bomber_walk.png","raw/bomber_restyle.png"),
}
def run(kv):
    n,(src,dst)=kv
    if os.path.exists(dst) and os.path.getsize(dst)>1000: return n,"cached"
    r=subprocess.run(["gpt-image","-i",src,STYLE,"--background","transparent","-a","wide","-o",dst,"-q"],capture_output=True,text=True)
    return n,"ok" if r.returncode==0 and os.path.exists(dst) else "FAIL "+r.stderr[-200:]
with cf.ThreadPoolExecutor(6) as ex:
    for n,s in ex.map(run,JOBS.items()): print(n,s,flush=True)
