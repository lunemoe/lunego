"""Procedural chiptune loops (CC0): dungeon exploration + boss fight. Rendered with numpy."""
import numpy as np, wave, os
SR=44100
def env(n, a=0.005, d=0.05, s=0.7, r=0.06, sus=None):
    a_n,d_n,r_n=int(a*SR) or 1,int(d*SR),int(r*SR)
    body=max(1,n-a_n-d_n-r_n)
    e=np.concatenate([np.linspace(0,1,a_n), np.linspace(1,s,d_n), np.full(body,s), np.linspace(s,0,r_n)])
    return e[:n] if len(e)>=n else np.pad(e,(0,n-len(e)))

def pulse(freq, n, duty=0.5, **kw):
    t=np.arange(n)/SR
    ph=(t*freq)%1.0
    w=np.where(ph<duty,1.0,-1.0)
    return w*env(n,**kw)

def tri(freq,n,**kw):
    t=np.arange(n)/SR
    ph=(t*freq)%1.0
    w=4*np.abs(ph-0.5)-1
    return w*env(n,**kw)

def noise(n, decay=0.999, hp=False):
    rng=np.random.default_rng(7)
    x=rng.uniform(-1,1,n)
    if hp: x=np.diff(np.concatenate([[0],x]))
    e=np.linspace(1,0,n)**3
    return x*e*0.5

NOTE={'C':0,'C#':1,'D':2,'D#':3,'E':4,'F':5,'F#':6,'G':7,'G#':8,'A':9,'A#':10,'B':11}
def f(name, octave):
    n=name[:-1] if len(name)>1 and name[-1].isdigit() else name
    return 440*2**((NOTE[n]+12*(octave-4)-9)/12)

def render(prog, bpm, bars, lead_pat, seed=1, lead_oct=5, aggressive=False):
    spb=60/bpm; beat=int(SR*spb)
    total=bars*4*beat
    buf=np.zeros(total+SR)
    def put(sig, pos):
        end=min(len(buf),pos+len(sig)); buf[pos:end]+=sig[:end-pos]
    for b in range(bars):
        root,third,fifth=prog[b%len(prog)]
        bar0=b*4*beat
        # bass: root on 1 and 3
        for i,off in enumerate((0,2)):
            put(tri(f(root,2), int(beat*0.9), s=0.9, r=0.02)*0.5, bar0+off*beat)
        # arp 16ths
        tones=[f(root,4),f(third,4),f(fifth,4),f(third,4)]
        for i in range(16):
            tone=tones[i%4]*(2 if (i//4)%2 else 1)
            put(pulse(tone,int(beat*0.22),duty=0.25,s=0.25,r=0.01)*0.16, bar0+i*beat//4)
        # lead melody every other bar
        if b%2==1:
            for i,(step,deg,dur) in enumerate(lead_pat):
                tone=f([root,third,fifth][deg%3], lead_oct)
                put(pulse(tone,int(beat*dur*0.95),duty=0.5,s=0.6,r=0.03)*0.22, bar0+int(step*beat))
        # drums
        put(noise(int(SR*0.03))*0.35, bar0)                      # kick-ish click
        for i in range(4):
            put(noise(int(SR*0.02),hp=True)*0.12, bar0+i*beat+beat//2)   # hats
        put(noise(int(SR*0.12))*0.25, bar0+2*beat)                # snare
        if aggressive:
            for i in range(8):
                put(noise(int(SR*0.012),hp=True)*0.10, bar0+i*beat//2)
    # gentle stereo-free mix + soft clip
    buf=np.tanh(buf*1.1)
    peak=np.abs(buf).max()
    if peak>0: buf=buf/peak*0.85
    return (buf*32767).astype(np.int16)

def save(sig, path, seconds=None):
    if seconds: sig=sig[:int(SR*seconds)]
    with wave.open(path,'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes(sig.tobytes())

# A minor: Am F C G  (root, third, fifth)
PROG=[('A',3,'C',4,'E',4),('F',3,'A',3,'C',4),('C',3,'E',3,'G',3),('G',3,'B',3,'D',4)]
prog=[(r,t,fi) for (r,_,t,_,fi,_) in PROG]
LEAD=[(0,0,1.0),(0.75,1,0.5),(1.5,2,0.5),(2,0,1.0),(3,1,0.5),(3.5,2,0.5)]
dungeon=render(prog, 100, 26, LEAD)   # 26 bars @100bpm 4/4 = 62.4s
save(dungeon,'dungeon_loop.wav')

PROG2=[('A',3,'C',4,'E',4),('A',3,'C',4,'F',4),('G',3,'B',3,'D',4),('E',3,'G#',3,'B',3)]
prog2=[(r,t,fi) for (r,_,t,_,fi,_) in PROG2]
LEAD2=[(0,0,0.5),(0.5,2,0.5),(1,1,1.0),(2,0,0.5),(2.5,1,0.5),(3,2,1.0)]
boss=render(prog2, 150, 33, LEAD2, aggressive=True)  # 33 bars @150 = 52.8s
save(boss,'boss_loop.wav')
print("music written")
