BASE = ("pixel art game sprite, crisp hard pixel edges, flat colours, thick dark outline, limited 16 colour palette, "
        "no text, no background scenery, transparent background")
KNIGHT = "hero knight in blue tabard with round shield and sword"
MAGE   = "battle mage in violet robe with pointed hat and wooden staff"
VIEW = {"down":"facing the FRONT toward the camera", "side":"in right-facing PROFILE walking/acting toward the right side",
        "up":"seen from BEHIND, back turned away from the camera"}
def strip(subject, view, action, n, extra=""):
    return (f"pixel art game sprite sheet, ONE character, exactly {n} frame {action} animation laid out in a single "
            f"horizontal row, {subject} {VIEW[view]}, top-down 3/4 view, evenly spaced frames, identical character design, "
            f"scale and pose baseline in every frame {extra}") 
