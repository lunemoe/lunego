incoming v2 pipeline (not shipped at runtime)

gen_anim.py     stage1 6-frame walk strips (raw), stage2 restyle to low-res pixel art,
                stage3 action strips (attack1/attack2/cast/death, enemy attack/death, boss phases)
                generated with the restyled walk as image reference so the design stays identical
gen_extra.py    5 effect strips + 4 UI icon rows
ui_gen.py       entire procedural UI kit (9-slice frames, slots, bars, CD masks, rarity, cursor)
music_gen.py    two numpy chiptune loops (dungeon 63s, boss 54s)
pixel.py        alpha strip splitter, 28-colour quantiser, speck cleanup
build_anim.py   player_knight/mage (4x30), enemies (6x5), boss (6x7)
build_fx.py     effects + icon atlases
build_manifest.py / build_preview.py   manifest.fragment.json + preview.png
tools/../tools/validate_incoming.py    validator (run from incoming/)

Order: gen_anim -> gen_extra -> build_anim -> build_fx -> build_manifest -> build_preview -> validate
raw/ deleted after shipping; prompts in the scripts are the source of truth.
