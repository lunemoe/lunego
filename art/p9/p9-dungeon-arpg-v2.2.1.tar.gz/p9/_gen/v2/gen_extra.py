import os, subprocess, concurrent.futures as cf
RAW="raw"
BASE=("pixel art, crisp hard pixel edges, flat colours, thick dark outline, limited 16 colour palette, "
      "no text, transparent background")
ICONS={
 "icons_stats":("icon sheet, exactly 8 icons in one horizontal row evenly spaced: flexed arm (strength), winged boot (dexterity), "
                "heart with cross (vitality), open book (intelligence), shield (armour), lightning bolt (attack speed), "
                "target crosshair (critical hit), four leaf clover (luck)"),
 "icons_elements":("icon sheet, exactly 6 icons in one horizontal row evenly spaced: orange flame (fire), light blue snowflake (ice), "
                   "yellow lightning bolt (lightning), green dripping drop (poison), golden sun cross (holy), purple crescent moon (shadow)"),
 "icons_skills_a":("icon sheet, exactly 6 spell skill icons in one horizontal row evenly spaced: falling meteor, spinning whirlwind, "
                   "green healing glow, blue magic shield, speed dash streaks, ice shard burst"),
 "icons_skills_b":("icon sheet, exactly 6 spell skill icons in one horizontal row evenly spaced: chain lightning, poison cloud, "
                   "summoned skeleton skull, blood rage, teleport portal, gold coin shower"),
}
FX={
 "fx_explosion":("explosion animation, exactly 6 frames in one horizontal row, fire and smoke blast expanding and fading"),
 "fx_hitspark":("impact spark animation, exactly 4 frames in one horizontal row, white and yellow sparks bursting outwards"),
 "fx_slash":("crescent sword slash arc animation, exactly 4 frames in one horizontal row, white blue energy arc sweeping"),
 "fx_levelup":("level up burst animation, exactly 6 frames in one horizontal row, golden light ring rising with sparkles"),
 "fx_pickup":("item pickup sparkle animation, exactly 4 frames in one horizontal row, small golden sparkles rising"),
}
def run(kv):
    name,p=kv; out=f"{RAW}/{name}.png"
    if os.path.exists(out) and os.path.getsize(out)>1000: return name,"cached"
    r=subprocess.run(["gpt-image",p+", "+BASE,"--background","transparent","-a","wide","-o",out,"-q"],capture_output=True,text=True)
    return name,"ok" if r.returncode==0 and os.path.exists(out) else "FAIL "+(r.stderr or "")[-150:]
jobs=[(k,v) for k,v in list(ICONS.items())+list(FX.items())]
with cf.ThreadPoolExecutor(5) as ex:
    for n,s in ex.map(run,jobs): print(n,s,flush=True)
