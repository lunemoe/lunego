"""Write manifest.fragment.json for incoming/."""
import json, os, subprocess
from PIL import Image
A="../"; AI=dict(kind="ai-generated", tool="gpt-image-2.5 (magpie gateway, local)", license="CC0-1.0",
                 author="generated for p9 (this repo)",
                 pipeline="gpt-image -> alpha strip split -> LANCZOS fit to frame -> shared 28-colour palette -> cleanup; "
                          "action strips conditioned on a restyled walk reference for design consistency")
PROC=dict(kind="procedural", tool="PIL/numpy generator in incoming/_gen/ui_gen.py", license="CC0-1.0",
          author="written for p9 (this repo)")
def ai(p): return {**AI,"prompt":p}
def dur(p):
    r=subprocess.run(["ffprobe","-v","error","-show_entries","format=duration","-of","csv=p=0",p],capture_output=True,text=True)
    return round(float(r.stdout.strip()),3)
def size(p): return Image.open(p).size

assets=[]
PLAYER_ANIMS=[("idle",[0,3],4,True,4),("walk",[4,9],6,True,10),("attack1",[10,13],4,False,12),
              ("attack2",[14,17],4,False,12),("cast",[18,21],4,False,10),("hurt",[22,23],2,False,12),
              ("death",[24,29],6,False,8)]
for cls in ("knight","mage"):
    f=f"sprites/player_{cls}.png"; w,h=size(A+f)
    assets.append({"id":f"player_{cls}","file":f,"type":"spritesheet","frameWidth":32,"frameHeight":32,
        "columns":w//32,"rows":4,"facingRows":{"0":"down","1":"left","2":"right","3":"up"},
        "anchor":"bottom-center","transparent":True,
        "animations":[{"name":n,"columns":c,"frames":fr,"loop":lp,"fps":fps} for n,c,fr,lp,fps in PLAYER_ANIMS],
        "source":ai("hero knight in blue tabard / battle mage in violet robe, 6-frame walk, 4-frame attack1/attack2/cast, "
                    "6-frame death strip per facing; idle = 4-frame 1px breathing bob derived from walk[0]; "
                    "hurt = 2-frame recoil derived from walk[0]; left row = build-time horizontal mirror of the right row"),
        "notes":"left row is mirrored from the right row; idle/hurt frames are derived, not generated"})
ENEMY_SPEC=[("idle",[0,3],4,True,4),("move",[0,5],6,True,10),("attack",[0,3],4,False,10),
            ("hurt",[0,1],2,False,12),("death",[0,5],6,False,8)]
for k,bh in (("slime","small"),("brute","large"),("caster","caster"),("charger","charger"),("bomber","bomber"),("elite","elite")):
    f=f"sprites/enemies/{k}.png"; w,h=size(A+f); fw=w//6
    assets.append({"id":f"enemy_{k}","file":f,"type":"spritesheet","frameWidth":fw,"frameHeight":fw,
        "columns":6,"rows":5,"facingRows":None,"anchor":"bottom-center","transparent":True,
        "rowOrder":["idle","move","attack","hurt","death"],
        "animations":[{"name":n,"row":i,"columns":c,"frames":fr,"loop":lp,"fps":fps} for i,(n,c,fr,lp,fps) in enumerate(ENEMY_SPEC)],
        "source":ai(f"{bh} enemy, 6-frame walk/move strip restyled to low-res pixel art, 4-frame attack and 6-frame death "
                    "generated from that reference; idle = bob from move[0]; hurt = 2-frame recoil"),
        "notes":"rows are animations, not facings"})
f="sprites/enemies/boss.png"; w,h=size(A+f)
BOSS_SPEC=[("idle",[0,3],4,True,4),("smash",[0,3],4,False,10),("charge",[0,3],4,False,12),
           ("projectile",[0,3],4,False,10),("phase",[0,3],4,False,8),("hurt",[0,1],2,False,12),
           ("death",[0,5],6,False,8)]
assets.append({"id":"enemy_boss","file":f,"type":"spritesheet","frameWidth":64,"frameHeight":64,
    "columns":6,"rows":7,"anchor":"bottom-center","transparent":True,
    "rowOrder":["idle","smash","charge","projectile","phase","hurt","death"],
    "animations":[{"name":n,"row":i,"columns":c,"frames":fr,"loop":lp,"fps":fps} for i,(n,c,fr,lp,fps) in enumerate(BOSS_SPEC)],
    "source":ai("horned demon lord, 4-frame idle, 4-frame ground smash, 4-frame charge, 4-frame fireball throw, "
                "4-frame enrage phase shift, 6-frame death; each strip generated from the restyled idle reference"),
    "notes":"rows are animations; boss is a 64x64 two-tile creature"})

FX={"fx_explosion":(32,6,"explosion"),"fx_hitspark":(16,4,"hit spark"),"fx_slash":(32,4,"sword slash arc"),
    "fx_levelup":(32,6,"level up burst"),"fx_pickup":(16,4,"pickup sparkle")}
for k,(sz,n,desc) in FX.items():
    f=f"sprites/effects/{k}.png"
    if not os.path.exists(A+f): continue
    assets.append({"id":k,"file":f,"type":"spritesheet","frameWidth":sz,"frameHeight":sz,"columns":n,"rows":1,
        "anchor":"center","transparent":True,
        "animations":[{"name":"default","columns":[0,n-1],"frames":n,"loop":False,"fps":14}],
        "source":ai(desc+" animation strip, AI generated then palette-quantised"),
        "notes":"effect strips are additive-friendly (transparent, bright cores)"})

ICONS={"icons_stats":("sprites/ui/icons_stats.png",16,8,
        "strength, dexterity, vitality, intelligence, armour, attack speed, critical hit, luck"),
       "icons_elements":("sprites/ui/icons_elements.png",16,6,"fire, ice, lightning, poison, holy, shadow"),
       "icons_skills":("sprites/ui/icons_skills.png",16,12,
        "meteor, whirlwind, heal, magic shield, dash, ice burst, chain lightning, poison cloud, skeleton summon, blood rage, portal, coin shower")}
for k,(f,sz,n,desc) in ICONS.items():
    if not os.path.exists(A+f): continue
    assets.append({"id":k,"file":f,"type":"icon-row","frameWidth":sz,"frameHeight":sz,"columns":n,"rows":1,
        "anchor":"top-left","transparent":True,"animations":[],"source":ai("UI icon row: "+desc),
        "notes":"column order: "+desc})

UI=[("ui_panel_normal","ui/panel_normal.png",True,"panel, normal state"),
    ("ui_panel_hover","ui/panel_hover.png",True,"panel, hover/highlight state"),
    ("ui_panel_pressed","ui/panel_pressed.png",True,"panel, pressed state"),
    ("ui_panel_disabled","ui/panel_disabled.png",True,"panel, disabled state"),
    ("ui_button_normal","ui/button_normal.png",True,"button, normal"),
    ("ui_button_hover","ui/button_hover.png",True,"button, hover"),
    ("ui_button_pressed","ui/button_pressed.png",True,"button, pressed"),
    ("ui_button_disabled","ui/button_disabled.png",True,"button, disabled"),
    ("ui_tab_active","ui/tab_active.png",True,"tab, active"),("ui_tab_inactive","ui/tab_inactive.png",True,"tab, inactive"),
    ("ui_slot_inventory","ui/slot_inventory.png",False,"inventory cell 32x32"),
    ("ui_slot_equipment","ui/slot_equipment.png",False,"equipment slot 32x32"),
    ("ui_slot_skill","ui/slot_skill.png",False,"skill slot 32x32"),
    ("ui_tooltip","ui/tooltip.png",True,"tooltip background 9-slice"),
    ("ui_minimap_frame","ui/minimap_frame.png",True,"minimap frame 9-slice"),
    ("ui_bar_hp_frame","ui/bar_hp_frame.png",True,"HP bar frame, horizontal 3-slice (cap 5px)"),
    ("ui_bar_mp_frame","ui/bar_mp_frame.png",True,"MP bar frame, horizontal 3-slice"),
    ("ui_bar_xp_frame","ui/bar_xp_frame.png",True,"XP bar frame, horizontal 3-slice"),
    ("ui_bar_stamina_frame","ui/bar_stamina_frame.png",True,"stamina bar frame, horizontal 3-slice"),
    ("ui_bar_hp_fill","ui/bar_hp_fill.png",False,"HP fill tile"),("ui_bar_mp_fill","ui/bar_mp_fill.png",False,"MP fill"),
    ("ui_bar_xp_fill","ui/bar_xp_fill.png",False,"XP fill"),("ui_bar_stamina_fill","ui/bar_stamina_fill.png",False,"stamina fill"),
    ("ui_cd_mask_1","ui/cd_mask_1.png",False,"cooldown mask, 25% wedge"),("ui_cd_mask_2","ui/cd_mask_2.png",False,"50%"),
    ("ui_cd_mask_3","ui/cd_mask_3.png",False,"75%"),("ui_cd_mask_4","ui/cd_mask_4.png",False,"100% (full cover)"),
    ("ui_cursor","ui/cursor.png",False,"mouse cursor 16x16")]
for c in ("common","uncommon","rare","epic","legendary"):
    UI.append((f"ui_rarity_{c}",f"ui/rarity_{c}.png",False,f"rarity border, {c}"))
for i,(id_,f,nine,desc) in enumerate(UI):
    if not os.path.exists(A+f): continue
    w,h=size(A+f)
    assets.append({"id":id_,"file":f,"type":"nine-slice" if nine else "ui-part","frameWidth":w,"frameHeight":h,
        "columns":1,"rows":1,"anchor":"top-left","transparent":True,"animations":[],
        "nineSlice":{"border":8,"cols":3} if nine else None,
        "source":{**PROC,"note":desc},"notes":desc})
assets.append({"id":"ui_rarity_atlas","file":"ui/rarity_frames.png","type":"atlas","frameWidth":32,"frameHeight":32,
    "columns":5,"rows":1,"anchor":"top-left","transparent":True,"animations":[],
    "source":{**PROC,"note":"5 rarity borders in one row"}, "notes":"column order: common, uncommon, rare, epic, legendary"})

AUDIO=[("ui_hover","menu hover","General Sounds/Menu Sounds/sfx_menu_move1.wav"),
 ("ui_click","menu click","General Sounds/Menu Sounds/sfx_menu_select1.wav"),
 ("ui_back","menu back","General Sounds/Menu Sounds/sfx_menu_select3.wav"),
 ("ui_error","menu error","General Sounds/Negative Sounds/sfx_sounds_error1.wav"),
 ("footstep_1","footstep A","Movement/Footsteps/sfx_movement_footsteps1a.wav"),
 ("footstep_2","footstep B","Movement/Footsteps/sfx_movement_footsteps1b.wav"),
 ("footstep_3","footstep C","Movement/Footsteps/sfx_movement_footsteps5.wav"),
 ("hit","hit impact","General Sounds/Impacts/sfx_sounds_impact3.wav"),
 ("slash","sword swing","Weapons/Melee/sfx_wpn_sword2.wav"),
 ("shoot","projectile","Weapons/Single Shot Sounds/sfx_weapon_singleshot4.wav"),
 ("skill_cast","skill cast","General Sounds/Positive Sounds/sfx_sounds_powerup6.wav"),
 ("skill_ready","skill ready","General Sounds/Positive Sounds/sfx_sounds_powerup11.wav"),
 ("hurt","player hurt","General Sounds/Simple Damage Sounds/sfx_damage_hit4.wav"),
 ("death","death","Death Screams/Human/sfx_deathscream_human5.wav"),
 ("pickup","pickup","General Sounds/Coins/sfx_coin_single3.wav"),
 ("levelup","level up","General Sounds/Fanfares/sfx_sounds_fanfare2.wav"),
 ("door_open","door","Movement/Opening Doors/sfx_movement_dooropen2.wav"),
 ("chest_open","chest","General Sounds/Interactions/sfx_sounds_interaction8.wav"),
 ("explosion","explosion","Explosions/Medium Length/sfx_exp_medium5.wav"),
 ("boss_roar","boss roar","Explosions/Long/sfx_exp_long1.wav"),
 ("boss_phase","boss phase shift","Explosions/Long/sfx_exp_long4.wav"),
 ("dodge","dodge roll","Movement/Jumping and Landing/sfx_movement_jump4.wav"),
 ("loot_drop","loot drop","General Sounds/Interactions/sfx_sounds_interaction12.wav"),
 ("enemy_spawn","enemy spawn","General Sounds/Weird Sounds/sfx_sound_vaporizing.wav")]
audio=[]
for n,desc,orig in AUDIO:
    f=f"audio/{n}.ogg"
    if not os.path.exists(A+f): continue
    audio.append({"id":f"sfx_{n}","file":f,"type":"audio","description":desc,"duration":dur(A+f),"format":"ogg/vorbis mono",
       "source":{"kind":"download","pack":"The Essential Retro Video Game Sound Effects Collection [512 sounds]",
                 "author":"Juhani Junkala (SubspaceAudio)","license":"CC0-1.0",
                 "url":"https://opengameart.org/content/512-sound-effects-8-bit-style","originalFile":orig,
                 "processing":"mono ogg q4; boss_roar/boss_phase pitch-shifted down 0.55x and re-timed"}})
for n,desc,minlen in (("dungeon_loop","dungeon exploration loop",55),("boss_loop","boss fight loop",45)):
    f=f"audio/{n}.ogg"
    if not os.path.exists(A+f): continue
    audio.append({"id":f"music_{n}","file":f,"type":"music","description":desc,"duration":dur(A+f),
       "format":"ogg/vorbis mono","loop":True,"minDuration":minlen,
       "source":{"kind":"procedural","tool":"incoming/_gen/music_gen.py (numpy chiptune renderer)","license":"CC0-1.0",
                 "author":"generated for p9 (this repo)","note":"square/triangle/noise synthesis, A minor progression, seamless bar-aligned length"}})

man={"pack":"p9-dungeon-arpg","fragment":"incoming/v2-animations-ui-audio","baseVersion":"1.0.0","created":"2026-11-02",
     "description":"Second-pass asset drop: full animation sets for 2 player classes and 7 enemies (incl. boss phases), "
                   "complete procedural pixel UI kit, expanded CC0 SFX and two procedural chiptune loops.",
     "virtualResolution":[480,270],"pixelScale":"integer only, nearest-neighbour",
     "palette":{"colors":["#101018","#1a1a26","#2e2f3d","#4a4c5e","#6b6e82","#9a9db2","#e8ecf4","#e8b48c","#b87b5c",
                          "#f2c14e","#b07c2a","#e8743a","#c8392b","#7a1a1c","#2f6fb8","#63a6e8","#1c2e4d","#6b3fa0",
                          "#a96bdc","#4fd6e8","#4fa64a","#8fd05a","#2a6636","#8a5a33","#4e3220","#f7e08a","#e86b9a","#d8cba8"],
                "note":"characters and icons quantised to these 28 colours; UI drawn from the same ramp"},
     "licenses":{"aiArt":"CC0-1.0","ui":"CC0-1.0","audio":"CC0-1.0","music":"CC0-1.0"},
     "anchorNote":"entities use bottom-center (feet at frame bottom - 2px); UI and effects use top-left/center as stated per asset",
     "integration":{"player":"replace sprites/player.png; rows 0..3 = down,left,right,up; column map per animation",
                    "enemies":"enemy sheets are 6x5: row0 idle(4f) row1 move(6f) row2 attack(4f) row3 hurt(2f) row4 death(6f); trailing cells in short rows are empty",
                    "boss":"boss is 6x7 at 64px: rows idle, smash, charge, projectile, phase, hurt, death (same column rule)",
                    "nineSlice":"all panels/buttons/tabs/tooltip/minimap use border 8 on a 32x32 source (stretch with nearest)"},
     "assets":assets,"audio":audio}
json.dump(man,open(A+"manifest.fragment.json","w"),indent=2,ensure_ascii=False)
print("fragment:",len(assets),"assets,",len(audio),"audio")
