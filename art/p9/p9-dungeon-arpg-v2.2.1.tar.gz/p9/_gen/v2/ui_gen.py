"""Procedural pixel UI kit: 9-slice frames, slots, bars, rarity, cursor, glyph icons."""
from PIL import Image
import numpy as np
OUT="/home/zero/Documents/lunego-workspace/games/p9/assets/incoming/ui"
S=32
INK=(16,16,24); DARK=(46,47,61); STONE=(74,76,94); STONE_L=(107,110,130); STONE_H=(154,157,178)
GOLD=(242,193,78); GOLD_D=(176,124,42); WHITE=(232,236,244); FILL=(26,26,38); FILL2=(34,34,48)
RED=(200,57,43); BLUE=(47,111,184); CYAN=(79,214,232); GREEN=(79,166,74); PURPLE=(169,107,220); PINK=(232,107,154)

def canvas(fill=None):
    a=np.zeros((S,S,4),np.uint8)
    if fill is not None: a[:,:]= (*fill,255)
    return a
def px(a,x,y,c,al=255): a[y%S,x%S]=(*c,al)
def hline(a,y,x0,x1,c):
    for x in range(x0,x1+1): px(a,x,y,c)
def vline(a,x,y0,y1,c):
    for y in range(y0,y1+1): px(a,x,y,c)
def rect(a,x0,y0,x1,y1,c):
    for y in range(y0,y1+1): hline(a,y,x0,x1,c)
def save(a,name): Image.fromarray(a,"RGBA").save(f"{OUT}/{name}.png")

def frame(fill, border, border_shadow, border_hi, inset=True, studs=True):
    a=canvas(fill)
    rect(a,0,0,S-1,S-1,INK)
    rect(a,1,1,S-2,S-2,border)
    rect(a,2,2,S-3,S-3,border_shadow)
    if inset:
        rect(a,3,3,S-4,S-4,DARK)
        rect(a,4,4,S-5,S-5,border_hi)
        rect(a,5,5,S-6,S-6,fill)
    if studs:
        for (x,y) in ((2,2),(S-3,2),(2,S-3),(S-3,S-3)):
            px(a,x,y,WHITE if border==GOLD else STONE_H)
    return a

save(frame(FILL2,GOLD,GOLD_D,STONE_L), "panel_normal")
save(frame((46,42,28),GOLD,(210,150,50),GOLD),"panel_hover")
save(frame((20,20,26),GOLD_D,(120,84,28),STONE), "panel_pressed")
save(frame((38,38,44),STONE_L,DARK,STONE),"panel_disabled")

save(frame((40,40,56),STONE_H,STONE_L,STONE),"button_normal")
save(frame((58,56,40),GOLD,GOLD_D,GOLD),"button_hover")
save(frame((26,26,32),STONE,DARK,STONE),"button_pressed")
save(frame((38,38,44),STONE,DARK,DARK),"button_disabled")

# tabs: 32x32 nine-slice, top edge shaped
def tab(active):
    a=frame((44,44,60) if active else (28,28,38), GOLD if active else STONE_L, GOLD_D if active else DARK, STONE, studs=False)
    if not active:
        for y in range(3,6):
            for x in range(3,S-3): px(a,x,y,DARK)
    return a
save(tab(True),"tab_active"); save(tab(False),"tab_inactive")

# inventory / equipment / skill slots: 32x32 cells
def slot(kind):
    a=canvas(FILL)
    rect(a,0,0,S-1,S-1,INK)
    rect(a,1,1,S-2,S-2,DARK)
    rect(a,2,2,S-3,S-3,STONE_L)
    rect(a,3,3,S-4,S-4,FILL2)
    # inner shadow top-left bevel
    hline(a,3,3,S-4,DARK); vline(a,3,3,S-4,DARK)
    hline(a,S-4,3,S-4,STONE); vline(a,S-4,3,S-4,STONE)
    if kind=="equipment":
        for (x,y) in [(4,4),(S-5,4),(4,S-5),(S-5,S-5)]: px(a,x,y,GOLD_D)
    if kind=="skill":
        for (x,y) in [(3,3),(S-4,3),(3,S-4),(S-4,S-4)]: px(a,x,y,GOLD)
    return a
save(slot("inventory"),"slot_inventory"); save(slot("equipment"),"slot_equipment")
save(slot("skill"),"slot_skill")

# cooldown mask: dark overlay with 4 radial wedge steps (frames), alpha 150
def cd(i):
    a=np.zeros((S,S,4),np.uint8)
    cx=cy=15.5
    for y in range(S):
        for x in range(S):
            ang=(np.degrees(np.arctan2(y-cy,x-cx))+90)%360
            if ang < 90*i/4 + 1e-6 or i==4:
                a[y,x]=(10,10,16,150)
    return a
for i in range(1,5): save(cd(i),f"cd_mask_{i}")

# bars: 16x16 horizontal 3-slice (cap 5 / mid 6 / cap 5)
def bar_frame(accent):
    a=canvas(FILL); B=16
    rect(a,0,0,B-1,B-1,INK)
    rect(a,1,1,B-2,B-2,accent)
    rect(a,2,2,B-3,B-3,DARK)
    rect(a,3,3,B-4,B-4,INK)
    return a
def bar_fill(c_hi,c_lo):
    a=canvas(None); B=16
    for y in range(3,B-3):
        for x in range(3,B-3):
            a[y,x]=(*c_hi,255) if y< (B-3)//2+1 else (*c_lo,255)
    for x in range(3,B-3): a[3,x]=(*WHITE,255)
    return a
for name,accent in (("hp",RED),("mp",BLUE),("xp",CYAN),("stamina",GREEN)):
    save(bar_frame(accent),f"bar_{name}_frame")
save(bar_fill(RED,(122,26,28)),"bar_hp_fill")
save(bar_fill((99,166,232),(28,46,77)),"bar_mp_fill")
save(bar_fill(CYAN,(40,90,110)),"bar_xp_fill")
save(bar_fill((143,208,90),(42,102,56)),"bar_stamina_fill")

# minimap frame (32x32 nine-slice, 8px border)
save(frame((20,26,34),STONE_H,STONE_L,(30,40,50)),"minimap_frame")

# tooltip: 9-slice, softer border
save(frame((24,24,34),STONE_H,(36,36,50),(28,28,40)),"tooltip")

# cursor 16x16 arrow
def cursor():
    B=16; a=np.zeros((B,B,4),np.uint8)
    pts=[(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(1,7),(1,8),(2,3),(2,4),(3,4),(3,5),(4,5),(4,6),(5,6),(5,7),(6,7),(6,8),(3,2),(4,3),(5,4),(6,5),(7,6)]
    for (x,y) in pts: a[y,x]=(*WHITE,255)
    for (x,y) in [(0,0),(0,1),(0,2),(0,3),(0,4),(0,5),(0,6),(0,7),(0,8),(0,9),(1,9),(2,7),(3,6),(4,7),(5,7),(6,8),(7,8),(8,8),
                  (2,2),(3,3),(4,4),(5,5),(6,6),(7,7),(8,8)]:
        if 0<=x<B and 0<=y<B: a[y,x]=(*INK,255)
    for (x,y) in pts:
        a[y,x]=(*WHITE,255)
    return a
Image.fromarray(cursor(),"RGBA").save(f"{OUT}/cursor.png")

# rarity borders 32x32 (5 columns atlas 160x32)
def rarity(col):
    a=np.zeros((S,S,4),np.uint8)
    for y in range(S):
        for x in range(S):
            d=min(x,y,S-1-x,S-1-y)
            if d==0: a[y,x]=(*INK,255)
            elif d==1: a[y,x]=(*col,255)
            elif d==2: a[y,x]=(*WHITE,255) if (x in (0,1,S-2,S-1) or y in (0,1,S-2,S-1)) else (*col,255)
            else: a[y,x]=(0,0,0,0)
    return a
RAR=[("common",(154,157,178)),("uncommon",(143,208,90)),("rare",(99,166,232)),("epic",(169,107,220)),("legendary",(242,193,78))]
atlas=Image.new("RGBA",(S*len(RAR),S),(0,0,0,0))
for i,(n,c) in enumerate(RAR):
    a=rarity(c); save(a,f"rarity_{n}"); atlas.paste(Image.fromarray(a,"RGBA"),(i*S,0))
atlas.save(f"{OUT}/rarity_frames.png")
print("ui frames ok")
