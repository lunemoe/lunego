from PIL import Image, ImageDraw
import json, os
A="/home/zero/Documents/lunego-workspace/games/p9/assets/incoming/"
man=json.load(open(A+"manifest.fragment.json"))
BG=(24,24,32); FG=(232,236,244); ACC=(242,193,78); SUB=(154,157,178)
W=1840; pad=14
items=[]
WARN=[]
def S(im,k): return im.resize((im.size[0]*k,im.size[1]*k),Image.NEAREST)
def P(name):
    p=A+name
    return Image.open(p).convert("RGBA") if os.path.exists(p) else None

blocks=[]
for cls in ("knight","mage"):
    im=P(f"sprites/player_{cls}.png")
    if im: blocks.append((f"PLAYER {cls}  32x32  rows=down/left/right/up  cols: idle0-3 walk4-9 atk1 10-13 atk2 14-17 cast18-21 hurt22-23 death24-29", im, 1))
en=[P(f"sprites/enemies/{k}.png") for k in ("slime","brute","caster","charger","bomber","elite")]
en=[i for i in en if i]
if en: blocks.append(("ENEMIES 32x32  rows: idle0-3 move4-9 attack10-13 hurt14-15 death16-21", en, 1))
b=P("sprites/enemies/boss.png")
if b: blocks.append(("BOSS 64x64  rows: idle0-3 smash4-7 charge8-11 projectile12-15 phase16-19 hurt20-21 death22-27", b, 1))
fx=[]
for k in ("fx_explosion","fx_slash","fx_levelup","fx_hitspark","fx_pickup"):
    im=P(f"sprites/effects/{k}.png")
    if im: fx.append(im)
if fx: blocks.append(("EFFECTS 16/32px strips", fx, 2))
ic=[]
for k in ("icons_stats","icons_elements","icons_skills"):
    im=P(f"sprites/ui/{k}.png")
    if im: ic.append(im)
if ic: blocks.append(("ICONS 16x16: stats(8) elements(6) skills(12)", ic, 3))
ui=Image.new("RGBA",(760,150),(0,0,0,0))
blocks.append(("UI KIT 32x32 nine-slice b=8 + slots + bars", [ui], 1))
def block_h(blk):
    c=blk[1]
    if isinstance(c,Image.Image): return c.size[1]*blk[2]+34
    if not c: return 34
    rows=1; wused=0; hmax=0
    for im in c:
        wim=im.size[0]*blk[2]
        if wused+wim>W-120: rows+=1; wused=0
        wused+=wim; hmax=max(hmax, im.size[1]*blk[2])
    return hmax*rows+34
H=40+sum(block_h(b) for b in blocks)+120
canvas=Image.new("RGB",(W,max(H,600)),BG); d=ImageDraw.Draw(canvas)
y=8
def label(t,color=ACC): 
    global y
    d.text((pad,y),t,fill=color); y+=15
for title,content,k in blocks:
    label(title)
    if title.startswith("UI KIT"):
        # compose a mock inventory window
        def nine(im,w,h,b=8):
            S0=im.size[0]; out=Image.new("RGBA",(w,h),(0,0,0,0)); seg=[0,b,S0-b,S0]; dst=[0,b,w-b,w]
            for j in range(3):
                for i in range(3):
                    p=im.crop((seg[i],seg[j],seg[i+1],seg[j+1])); tw,th=dst[i+1]-dst[i],dst[j+1]-dst[j]
                    if tw>0 and th>0: out.paste(p.resize((tw,th),Image.NEAREST),(dst[i],dst[j]))
            return out
        pn=P("ui/panel_normal.png")
        if pn: canvas.paste(nine(pn,384,150).convert("RGB"),(pad,y))
        btn=P("ui/button_normal.png"); bt2=P("ui/button_hover.png")
        if btn: canvas.paste(nine(btn,96,26).convert("RGB"),(pad+8,y+8))
        if bt2: canvas.paste(nine(bt2,96,26).convert("RGB"),(pad+112,y+8))
        tab=P("ui/tab_active.png"); tb2=P("ui/tab_inactive.png")
        if tab: canvas.paste(nine(tab,64,20).convert("RGB"),(pad+220,y+10))
        if tb2: canvas.paste(nine(tb2,64,20).convert("RGB"),(pad+288,y+10))
        x=pad+8
        for nm in ("slot_inventory","slot_equipment","slot_skill"):
            s=P(f"ui/{nm}.png")
            if s: canvas.paste(s.convert("RGB"),(x,y+44)); x+=36
        # icons inside slots
        for i,nm in enumerate(("sword","armor","amulet")):
            ip=P(f"sprites/items/{nm}.png")
            if ip: canvas.paste(S(ip,1).convert("RGB"),(pad+12+i*36,y+48),S(ip,1))
        x=pad+120
        for nm,fill in (("hp",(200,57,43)),("mp",(47,111,184)),("xp",(79,214,232))):
            fr=P(f"ui/bar_{nm}_frame.png")
            if fr: canvas.paste(nine(fr,120,12,5).convert("RGB"),(x,y+46))
            bar=Image.new("RGB",(110,6),fill); canvas.paste(bar,(x+5,y+49))
            x+=126
        curs=P("ui/cursor.png")
        if curs: canvas.paste(S(curs,2).convert("RGB"),(pad+8,y+82),S(curs,2))
        rar=P("ui/rarity_frames.png")
        if rar:
            for i in range(5):
                canvas.paste(rar.crop((i*32,0,i*32+32,32)).convert("RGB"),(pad+40+i*34,y+78))
        d.text((pad+250,y+84),"rarity: common uncommon rare epic legendary",fill=SUB)
        d.text((pad+8,y+116),"panel/button/tab = 9-slice border8   bars = horizontal 3-slice cap5   slots 32x32   cursor 16x16",fill=SUB)
        y+=150
    elif isinstance(content,Image.Image):
        s=S(content,k); canvas.paste(s,(pad,y),s); y+=s.size[1]+12
    else:
        x=pad; rowh=0
        for im in content:
            s=S(im,k); canvas.paste(s,(x,y),s); x+=s.size[0]+10
            rowh=max(rowh,s.size[1])
            if x>W-200: x=pad; y+=rowh+8; rowh=0
        y+=rowh+12
label("AUDIO: see manifest.fragment.json (24 CC0 sfx + 2 procedural loops)", SUB)
canvas=canvas.crop((0,0,W,y+8))
canvas.save(A+"preview.png"); print("preview",canvas.size)
