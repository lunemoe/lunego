import sys; sys.path.insert(0,'.')
import pixel, numpy as np
from PIL import Image
def cell(im, size, pad=0):
    w,h=im.size; s=min((size-2*pad)/w,(size-2*pad)/h)
    nw,nh=max(1,round(w*s)),max(1,round(h*s))
    c=Image.new("RGBA",(size,size),(0,0,0,0))
    c.paste(im.resize((nw,nh),Image.LANCZOS),((size-nw)//2,(size-nh)//2))
    return pixel.cleanup(pixel.quantize(c))
def build(src,name,size,n,out,center=True):
    fr=pixel.frames_to_img(pixel.split_strip(pixel.load_rgba(f"raw/{src}.png"),n))
    print(src,len(fr))
    sh=Image.new("RGBA",(n*size,size),(0,0,0,0))
    for i,im in enumerate(fr): sh.paste(cell(im,size,0),(i*size,0))
    sh.save(out); print(out, sh.size)
build("fx_explosion","explosion",32,6,"../sprites/effects/fx_explosion.png")
build("fx_hitspark","hitspark",16,4,"../sprites/effects/fx_hitspark.png")
build("fx_slash","slash",32,4,"../sprites/effects/fx_slash.png")
build("fx_levelup","levelup",32,6,"../sprites/effects/fx_levelup.png")
build("fx_pickup","pickup",16,4,"../sprites/effects/fx_pickup.png")
# icons
import os
os.makedirs("../sprites/ui", exist_ok=True)
def icons(names_specs, out, size=16):
    cells=[]
    for src,n in names_specs:
        cells += pixel.frames_to_img(pixel.split_strip(pixel.load_rgba(f"raw/{src}.png"),n))
    sh=Image.new("RGBA",(len(cells)*size,size),(0,0,0,0))
    for i,im in enumerate(cells): sh.paste(cell(im,size,0),(i*size,0))
    sh.save(out); print(out, sh.size, len(cells))
icons([("icons_stats",8)],"../sprites/ui/icons_stats.png")
icons([("icons_elements",6)],"../sprites/ui/icons_elements.png")
a=pixel.frames_to_img(pixel.split_strip(pixel.load_rgba("raw/icons_skills_a.png"),6))
b=pixel.frames_to_img(pixel.split_strip(pixel.load_rgba("raw/icons_skills_b.png"),6))
sh=Image.new("RGBA",(12*16,16),(0,0,0,0))
for i,im in enumerate(a+b): sh.paste(cell(im,16,0),(i*16,0))
sh.save("../sprites/ui/icons_skills.png"); print("../sprites/ui/icons_skills.png", sh.size)
