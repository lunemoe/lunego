"""Assemble animation spritesheets from generated strips (crunch + palette + grids)."""
import sys, os; sys.path.insert(0,'.')
import pixel, numpy as np
from PIL import Image

FW=32; PADX,PADY=2,2
CLASSES=("knight","mage")
DIRS=("down","side","up")
COLSPEC=[("idle",4),("walk",6),("attack1",4),("attack2",4),("cast",4),("hurt",2),("death",6)]

def strip(name, n, fw=FW, fh=FW):
    p=f"raw/{name}.png"
    assert os.path.exists(p), p
    fr=pixel.frames_to_img(pixel.split_strip(pixel.load_rgba(p), n))
    if len(fr)!=n:
        print(f"  !! {name}: got {len(fr)} of {n} frames")
    return fr

def quant(im, fw, fh, s, padx=PADX, pady=PADY):
    w,h=im.size; k=min(s,(fw-2*padx)/w,(fh-pady-2)/h)
    nw,nh=max(1,round(w*k)),max(1,round(h*k))
    c=Image.new("RGBA",(fw,fh),(0,0,0,0))
    c.paste(im.resize((nw,nh),Image.LANCZOS),((fw-nw)//2, fh-pady-nh))
    return pixel.cleanup(pixel.quantize(c))

def shift(im,dx=0,dy=0):
    c=Image.new("RGBA",im.size,(0,0,0,0)); c.paste(im,(dx,dy)); return c

def build_player(cls):
    rows=[]
    for d in DIRS:
        walk=strip(f"{cls}_walk_{d}_rs",6)
        s=min(26/np.median([i.size[1] for i in walk]), 28/np.median([i.size[0] for i in walk]))
        cols={}
        cols["idle"]=[quant(shift(walk[0],0,-dy),FW,FW,s) for dy in (0,1,1,0)]
        cols["walk"]=[quant(i,FW,FW,s) for i in walk]
        for k in ("attack1","attack2","cast"):
            cols[k]=[quant(i,FW,FW,s) for i in strip(f"{cls}_{k}_{d}",4)]
        cols["hurt"]=[quant(shift(walk[0],-2 if d=="side" else 0, 2 if d=="down" else -2),FW,FW,s),
                      quant(shift(walk[0],-4 if d=="side" else 0, 3 if d=="down" else -3),FW,FW,s)]
        cols["death"]=[quant(i,FW,FW,s) for i in strip(f"{cls}_death_{d}",6)]
        rows.append(cols)
    # insert left row as a horizontal mirror of the right-facing (side) row
    left={k:[c.transpose(Image.FLIP_LEFT_RIGHT) for c in v] for k,v in rows[1].items()}
    rows=[rows[0], left, rows[1], rows[2]]
    W=sum(n for _,n in COLSPEC); H=4
    sheet=Image.new("RGBA",(W*FW,H*FW),(0,0,0,0))
    for r,cols in enumerate(rows):
        x=0
        for name,n in COLSPEC:
            for i,c in enumerate(cols[name][:n]): sheet.paste(c,((x+i)*FW, r*FW))
            x+=n
    sheet.save(f"../sprites/player_{cls}.png")
    print(f"../sprites/player_{cls}.png", sheet.size)
    return sheet

ENEMY_SPEC=[("idle",4),("move",6),("attack",4),("hurt",2),("death",6)]
def build_enemy(key, SZ=32, bh=26):
    walk=strip(f"{key}_walk_rs",6)
    s=min(bh/np.median([i.size[1] for i in walk]), (SZ-4)/np.median([i.size[0] for i in walk]))
    anim={}
    anim["idle"]=[quant(shift(walk[0],0,-dy),SZ,SZ,s) for dy in (0,1,1,0)]
    anim["move"]=[quant(i,SZ,SZ,s) for i in walk]
    anim["attack"]=[quant(i,SZ,SZ,s) for i in strip(f"{key}_attack",4)]
    anim["hurt"]=[quant(shift(walk[0],-2,-1),SZ,SZ,s), quant(shift(walk[0],-4,-2),SZ,SZ,s)]
    anim["death"]=[quant(i,SZ,SZ,s) for i in strip(f"{key}_death",6)]
    W=max(n for _,n in ENEMY_SPEC)
    sheet=Image.new("RGBA",(W*SZ,len(ENEMY_SPEC)*SZ),(0,0,0,0))
    for r,(name,n) in enumerate(ENEMY_SPEC):
        for i,c in enumerate(anim[name][:n]): sheet.paste(c,(i*SZ, r*SZ))
    sheet.save(f"../sprites/enemies/{key}.png")
    print(f"../sprites/enemies/{key}.png", sheet.size)

BOSS_SPEC=[("idle",4),("smash",4),("charge",4),("projectile",4),("phase",4),("hurt",2),("death",6)]
def build_boss():
    SZ=64; bh=54
    idle=strip("boss_idle_rs",4)
    s=min(bh/np.median([i.size[1] for i in idle]), (SZ-4)/np.median([i.size[0] for i in idle]))
    anim={k:[quant(i,SZ,SZ,s) for i in strip(f"boss_{k}", n)] for k,n in
          (("smash",4),("charge",4),("projectile",4),("phase",4),("death",6))}
    anim["idle"]=[quant(i,SZ,SZ,s) for i in idle]
    anim["hurt"]=[quant(shift(idle[0],-4,-2),SZ,SZ,s), quant(shift(idle[0],-8,-4),SZ,SZ,s)]
    W=max(n for _,n in BOSS_SPEC)
    sheet=Image.new("RGBA",(W*SZ,len(BOSS_SPEC)*SZ),(0,0,0,0))
    for r,(name,n) in enumerate(BOSS_SPEC):
        for i,c in enumerate(anim[name][:n]): sheet.paste(c,(i*SZ, r*SZ))
    sheet.save("../sprites/enemies/boss.png"); print("../sprites/enemies/boss.png", sheet.size)

if __name__=="__main__":
    for c in CLASSES:
        try: build_player(c)
        except AssertionError as e: print("skip", e)
    for k,bh in (("slime",22),("brute",26),("caster",26),("charger",22),("bomber",24),("elite",30)):
        try: build_enemy(k, 32, bh)
        except AssertionError as e: print("skip", e)
    try: build_boss()
    except AssertionError as e: print("skip", e)
