import os, subprocess, concurrent.futures as cf, sys
RAW="raw"; os.makedirs(RAW, exist_ok=True)
BASE=("pixel art game sprite, crisp hard pixel edges, flat colours, thick dark outline, limited 16 colour palette, "
      "no text, no background scenery, transparent background")
RS=("redraw this exact sprite sheet as clean low resolution pixel art, same number of frames in one horizontal row, "
    "same character design and poses, flat colours only, hard pixel edges, no anti-aliasing, no blur, "
    "high contrast readable silhouette, thick dark outline, transparent background")
SAME=("same character, same art style, same scale and same costume as the reference sheet, colour palette unchanged: ")

CLASSES={
 "knight": dict(desc="hero knight in blue tabard with round shield and sword",
                attacks=["horizontal sword slash attack","heavy overhead sword chop"],
                cast="raising a gauntleted fist that charges a cyan rune"),
 "mage":   dict(desc="battle mage in violet robe with pointed hat and wooden staff",
                attacks=["wide staff swing attack","thrusting the staff forward to fire a bolt"],
                cast="channeling a spell, both hands glowing with cyan magic"),
}
VIEW={"down":"facing the FRONT toward the camera","side":"in right-facing PROFILE, acting toward the right side",
      "up":"seen from BEHIND, back turned away from the camera"}
DIRS=["down","side","up"]

def prompt_walk(desc,view): 
    return (f"pixel art game sprite sheet, ONE character, exactly 6 frame walk cycle laid out in a single horizontal row, "
            f"{desc} {VIEW[view]}, top-down 3/4 view, evenly spaced frames, identical character design and scale in every frame")

def run(name, args):
    out=f"{RAW}/{name}.png"
    if os.path.exists(out) and os.path.getsize(out)>1000: return name,"cached"
    r=subprocess.run(["gpt-image"]+args+["--background","transparent","-a","wide","-o",out,"-q"],capture_output=True,text=True)
    return name, "ok" if r.returncode==0 and os.path.exists(out) else "FAIL "+(r.stderr or "")[-200:]

def batch(jobs, label, workers=6):
    print(f"=== {label}: {len(jobs)} jobs", flush=True)
    with cf.ThreadPoolExecutor(workers) as ex:
        for n,s in ex.map(lambda kv: run(*kv), jobs): print(" ",n,s,flush=True)

# stage 1: walk strips (raw detail)
jobs=[]
for cls,c in CLASSES.items():
    for d in DIRS: jobs.append((f"{cls}_walk_{d}", [prompt_walk(c["desc"],d)+", "+BASE]))
# stage 1 enemies
ENEMY={"slime":("small translucent lime slime blob with two dark eyes","bouncing hop movement"),
       "brute":("hulking red-skinned brute ogre with iron shoulder plates and a huge cleaver axe","heavy lumbering walk"),
       "caster":("hooded purple cultist mage with a glowing cyan orb staff","floating drift movement"),
       "charger":("armored tusked boar beast with rusty iron plates","galloping run toward the right"),
       "bomber":("round bomb creature with a lit fuse, stubby legs and angry eyes","waddling movement"),
       "elite":("elite dark knight in black plate armour with glowing violet runes and a horned helmet","menacing slow walk")}
for k,(desc,move) in ENEMY.items():
    jobs.append((f"{k}_walk", [f"pixel art game sprite sheet, ONE creature, exactly 6 frame {move} animation laid out in a single "
                               f"horizontal row, {desc}, facing the camera in top-down 3/4 view, evenly spaced frames, "
                               f"identical design and scale, "+BASE]))
jobs.append(("boss_idle", ["pixel art game sprite sheet, ONE boss creature, exactly 4 frame idle breathing animation laid out in a "
                           "single horizontal row, enormous horned demon lord with black iron crown, glowing orange eyes, huge flaming "
                           "cleaver, dark obsidian skin with red cracks, facing the camera in top-down 3/4 view, identical design and scale, "+BASE]))
batch(jobs,"walk strips")

# stage 2: restyle every walk strip -> canonical
jobs=[(f"{n}_rs", ["-i", f"{RAW}/{n}.png", RS]) for n,_ in jobs if os.path.exists(f"{RAW}/{n}.png")]
batch(jobs,"restyle")

# stage 3: actions conditioned on canonical walk
jobs=[]
for cls,c in CLASSES.items():
    for d in DIRS:
        ref=f"{RAW}/{cls}_walk_{d}_rs.png"
        if not os.path.exists(ref): continue
        for i,a in enumerate(c["attacks"],1):
            jobs.append((f"{cls}_attack{i}_{d}", ["-i",ref,SAME+f"exactly 4 frame {a}, laid out in one horizontal row, frame1 wind up, "
                         "frame2 strike, frame3 impact, frame4 recovery, transparent background"]))
        jobs.append((f"{cls}_cast_{d}", ["-i",ref,SAME+f"exactly 4 frame spell cast animation, {c['cast']}, one horizontal row, transparent background"]))
        jobs.append((f"{cls}_death_{d}", ["-i",ref,SAME+"exactly 6 frame death animation, the character is struck, staggers back, drops to the "
                     "knees and collapses flat on the ground, one horizontal row, transparent background"]))
for k,(desc,_) in ENEMY.items():
    ref=f"{RAW}/{k}_walk_rs.png"
    if not os.path.exists(ref): continue
    act={"slime":"lunging bite attack","brute":"overhead axe smash","caster":"raising the staff and firing a bolt",
         "charger":"charging headbutt lunge","bomber":"inflating for a self destruct blast","elite":"heavy sword slam"}[k]
    jobs.append((f"{k}_attack", ["-i",ref,SAME+f"exactly 4 frame {act}, one horizontal row, transparent background"]))
    jobs.append((f"{k}_death", ["-i",ref,SAME+"exactly 6 frame death animation, the creature is struck, reels back and collapses into a heap, "
                 "one horizontal row, transparent background"]))
bossref=f"{RAW}/boss_idle_rs.png"
if os.path.exists(bossref):
    for n,a in [("smash","4 frame ground smash attack, raising the flaming cleaver overhead then slamming it into the ground"),
                ("charge","4 frame charging run, leaning forward with the cleaver and a red speed aura"),
                ("projectile","4 frame casting attack, hurling a ball of fire forward"),
                ("phase","4 frame enrage transition, roaring with red energy erupting around the body"),
                ("death","6 frame death, the demon staggers, falls to its knees and crumbles into ash")]:
        jobs.append((f"boss_{n}", ["-i",bossref,SAME+f"exactly {a.split(' ')[0]} frame {a}, one horizontal row, transparent background"]))
batch(jobs,"actions")
print("done")
