import subprocess, concurrent.futures as cf, os
OUT="raw"; os.makedirs(OUT, exist_ok=True)
BASE="pixel art game sprite, crisp hard pixel edges, flat colors, thick dark outline, limited 16 color palette, no text, no background scenery"
P={
 "player_cast_down": "pixel art game sprite sheet, ONE character, exactly 3 frame spell casting animation in a single horizontal row, hero knight in blue tabard raising a gauntleted fist that emits a cyan magic glow, facing the FRONT of the camera, top-down 3/4 view, evenly spaced frames, identical character design and scale",
 "player_cast_up": "pixel art game sprite sheet, ONE character, exactly 3 frame spell casting animation in a single horizontal row, hero knight seen from BEHIND raising a gauntleted fist that emits a cyan magic glow, top-down 3/4 view, evenly spaced frames, identical character design and scale",
 "player_cast_side": "pixel art game sprite sheet, ONE character, exactly 3 frame spell casting animation in a single horizontal row, hero knight in right-facing PROFILE raising a gauntleted fist that emits a cyan magic glow to the right, top-down 3/4 view, evenly spaced frames, identical character design and scale",
 "player_death_down": "pixel art game sprite sheet, ONE character, exactly 5 frame death animation in a single horizontal row, hero knight in blue tabard collapsing and falling to the ground, facing the camera, top-down 3/4 view, evenly spaced frames, identical character design and scale",
 "player_death_side": "pixel art game sprite sheet, ONE character, exactly 5 frame death animation in a single horizontal row, hero knight in blue tabard collapsing and falling to the ground in right-facing profile, top-down 3/4 view, evenly spaced frames, identical character design and scale",
 "boss_walk": "pixel art game sprite sheet, ONE boss creature, exactly 4 frame idle breathing animation in a single horizontal row, enormous horned demon lord with black iron crown, glowing orange eyes, huge flaming cleaver, dark obsidian skin with red cracks, larger and more detailed than a normal monster, facing the camera in top-down 3/4 view, identical design and scale",
 "tile_door_closed": "pixel art game tile, ONE closed dungeon door made of dark oak planks with iron bands and a round handle, flat top-down front-facing view, crisp pixels, limited palette, no perspective shift",
 "tile_door_open": "pixel art game tile, ONE open dungeon doorway with a dark empty passage and a raised iron portcullis, flat top-down front-facing view, crisp pixels, limited palette",
 "tile_stairs_down": "pixel art game tile, stone staircase descending into darkness, flat top-down view, grey steps going down, crisp pixels, limited palette, tileable edges",
 "tile_crate": "pixel art game sprite, ONE destructible wooden barrel and crate set side by side, top-down 3/4 view, brown wood with iron hoops, crisp pixels, transparent background",
 "tile_pillar": "pixel art game sprite, ONE broken stone dungeon pillar, top-down 3/4 view, cracked grey stone, crisp pixels, transparent background",
 "item_sword": "pixel art game inventory icon, ONE steel broadsword with gold crossguard, diagonal orientation, crisp pixels, transparent background, centered",
 "item_armor": "pixel art game inventory icon, ONE steel chest plate armor with blue cloth, crisp pixels, transparent background, centered",
 "item_amulet": "pixel art game inventory icon, ONE gold amulet with a glowing violet gem, crisp pixels, transparent background, centered",
 "item_runestone": "pixel art game inventory icon, ONE carved stone rune tablet glowing cyan, crisp pixels, transparent background, centered",
 "ui_icons2": "pixel art game UI icon sheet, exactly 5 icons in a single horizontal row evenly spaced on a transparent background: brown leather backpack, knight helmet character portrait, open spell book, gold gear cog, wooden shield; flat colors, thick dark outline, crisp pixels, no text, each icon centered in its own square cell",
}
def run(kv):
    n,p=kv; f=f"{OUT}/{n}.png"
    if os.path.exists(f) and os.path.getsize(f)>1000: return n,"cached"
    r=subprocess.run(["gpt-image",p+BASE,"--background","transparent","-a","wide" if ("sheet" in p and "horizontal" in p and "row" in p and ("icons" in n or "walk" in n or "attack" in n or "cast" in n or "death" in n or "ui_icons" in n)) else "square","-o",f,"-q"],capture_output=True,text=True)
    if r.returncode!=0 or not os.path.exists(f): return n,"FAIL "+r.stderr[-200:]
    return n,"ok"
with cf.ThreadPoolExecutor(5) as ex:
    for n,s in ex.map(run,P.items()): print(n,s,flush=True)
