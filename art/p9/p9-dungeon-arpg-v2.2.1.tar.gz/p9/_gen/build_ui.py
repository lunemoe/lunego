from PIL import Image
import numpy as np
S=32
P=dict(ink=(16,16,24), dark=(46,47,61), frame=(74,76,94), frame_l=(107,110,130),
       gold=(242,193,78), gold_d=(176,124,42), fill=(26,26,38), fill2=(34,34,48), white=(232,236,244))

def frame_art(inner_fill, border, border_shadow):
    a=np.zeros((S,S,4),np.uint8); a[:,:,3]=255; a[:,:,:3]=np.array(inner_fill)
    band=[P["ink"], border, border, border_shadow, P["dark"], P["frame_l"], P["frame"], inner_fill]
    for i,c in enumerate(band):
        a[i,:,:3]=c; a[S-1-i,:,:3]=c
        a[:,i,:3]=c; a[:,S-1-i,:3]=c
    # corner brackets: gold 2x2 studs inside each corner (within the 8px corner slice)
    for (cx,cy) in ((1,1),(S-2,1),(1,S-2),(S-2,S-2)):
        a[cy,cx,:3]=P["white"]
    for (cx,cy) in ((2,1),(1,2),(S-3,1),(S-2,2),(1,S-3),(2,S-2),(S-2,S-3),(S-3,S-2)):
        a[cy,cx,:3]=P["gold"]
    return a

Image.fromarray(frame_art((40,40,56),P["gold"],P["gold_d"]),"RGBA").save("../ui/panel.png")
Image.fromarray(frame_art((44,44,60),P["frame_l"],P["dark"]),"RGBA").save("../ui/button.png")
Image.fromarray(frame_art((22,34,52),P["gold"],P["gold_d"]),"RGBA").save("../ui/panel_blue.png")

def nine(path,w,h,b=8):
    im=Image.open(path).convert("RGBA"); out=Image.new("RGBA",(w,h),(0,0,0,0))
    seg=[0,b,S-b,S]; dst=[0,b,w-b,w]
    for j in range(3):
        for i in range(3):
            p=im.crop((seg[i],seg[j],seg[i+1],seg[j+1]))
            tw,th=dst[i+1]-dst[i],dst[j+1]-dst[j]
            if tw>0 and th>0: out.paste(p.resize((tw,th),Image.NEAREST),(dst[i],dst[j]))
    return out
bg=Image.new("RGBA",(240,160),(28,28,36,255))
bg.alpha_composite(nine("../ui/panel.png",200,120),(20,15))
bg.alpha_composite(nine("../ui/button.png",80,28),(20,126))
bg.resize((480,320),Image.NEAREST).save("prev_ui.png")
print("ui ok")
