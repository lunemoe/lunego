import subprocess, concurrent.futures as cf, os
STYLE = ("redraw this exact sprite sheet as clean low resolution pixel art, same number of frames in one row, "
         "same character design and same poses, only flat colours, hard pixel edges, no anti-aliasing, no blur, "
         "high contrast readable silhouette, thick dark outline, transparent background")
JOBS = {
 "brute":  ("raw/brute_walk_simple.png", "raw/brute_restyle.png"),
 "charger":("raw/charger_walk_simple.png","raw/charger_restyle.png"),
 "boss":   ("raw/boss_walk.png",          "raw/boss_restyle.png"),
 "pw_down":("raw/player_walk_down.png",   "raw/pw_down_restyle.png"),
 "pw_side":("raw/player_walk_side.png",   "raw/pw_side_restyle.png"),
}
def run(kv):
    n,(src,dst)=kv
    if os.path.exists(dst) and os.path.getsize(dst)>1000: return n,"cached"
    r=subprocess.run(["gpt-image","-i",src,STYLE,"--background","transparent","-a","wide","-o",dst,"-q"],capture_output=True,text=True)
    return n,"ok" if r.returncode==0 and os.path.exists(dst) else "FAIL "+r.stderr[-200:]
with cf.ThreadPoolExecutor(5) as ex:
    for n,s in ex.map(run,JOBS.items()): print(n,s,flush=True)
