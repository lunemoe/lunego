import sys; sys.path.insert(0,'.')
import pixel, numpy as np
from PIL import Image

FW=FH=32; PADX,PADY=2,2; BODY_H=28
SRC={
 "walk_down":"raw/pw_down_restyle.png","walk_up":"raw/pw_up_restyle.png","walk_side":"raw/pw_side_restyle.png",
 "attack_down":"raw/pa_down_restyle.png","attack_up":"raw/pa_up_restyle.png","attack_side":"raw/pa_side_restyle.png",
 "cast_down":"raw/pc_down_restyle.png","cast_up":"raw/pc_up_restyle.png","cast_side":"raw/pc_side_restyle.png",
 "death_down":"raw/pd_down_restyle.png","death_side":"raw/pd_side_restyle.png",
}
CACHE={}
def strip(key,n):
    if key in CACHE: return CACHE[key]
    fr=pixel.split_strip(pixel.load_rgba(SRC[key]),n)
    assert len(fr)==n,(key,len(fr))
    ims=pixel.frames_to_img(fr); CACHE[key]=ims; return ims

def fit(im,s):
    w,h=im.size; s=min(s,(FW-2*PADX)/w,(FH-PADY-2)/h)
    nw,nh=max(1,round(w*s)),max(1,round(h*s))
    c=Image.new("RGBA",(FW,FH),(0,0,0,0))
    c.paste(im.resize((nw,nh),Image.LANCZOS),((FW-nw)//2, FH-PADY-nh))
    return pixel.cleanup(pixel.quantize(c))

def shift(im,dx=0,dy=0):
    c=Image.new("RGBA",im.size,(0,0,0,0)); c.paste(im,(dx,dy)); return c

ROWS={
 "down":  dict(walk="walk_down", attack="attack_down", cast="cast_down", death="death_down"),
 "left":  dict(walk="walk_side", attack="attack_side", cast="cast_side", death="death_side"),
 "right": dict(walk="walk_side", attack="attack_side", cast="cast_side", death="death_side"),
 "up":    dict(walk="walk_up",   attack="attack_up",   cast="cast_up",   death="death_down"),
}
ACT=[("idle",2),("walk",4),("attack",3),("cast",3),("hurt",1),("death",5)]
W=sum(c for _,c in ACT); H=len(ROWS)
REF_H=np.median([im.size[1] for im in strip("walk_down",4)]); GLOBAL_S=BODY_H/REF_H
print("global scale",round(GLOBAL_S,4),"ref h",REF_H)
sheet=Image.new("RGBA",(W*FW,H*FH),(0,0,0,0))
stats={}
for ri,(row,r) in enumerate(ROWS.items()):
    walk=strip(r["walk"],4); atk=strip(r["attack"],3); cast=strip(r["cast"],3); death=strip(r["death"],5)
    mw=np.median([i.size[0] for i in walk]); mh=np.median([i.size[1] for i in walk])
    s=min(BODY_H/mh,(FW-2*PADX)/mw)
    cells={}
    cells["idle"]=[fit(walk[0],s), fit(shift(walk[0],0,-1),s)]  # 1px breathing bob
    cells["walk"]=[fit(im,s) for im in walk]
    cells["attack"]=[fit(im,s) for im in atk]
    cells["cast"]=[fit(im,s) for im in cast]
    hurt_src=shift(walk[0], -2 if row=="right" else 2 if row=="left" else 0, 2 if row=="down" else -2)
    cells["hurt"]=[fit(hurt_src,s)]
    cells["death"]=[fit(im,s) for im in death]
    if row=="left":
        for k in cells: cells[k]=[c.transpose(Image.FLIP_LEFT_RIGHT) for c in cells[k]]
    x=0
    for name,cnt in ACT:
        for i,c in enumerate(cells[name][:cnt]):
            sheet.paste(c,((x+i)*FW, ri*FH))
        x+=cnt
    stats[row]=round(s,4)
sheet.save("../sprites/player.png")
print("player.png",sheet.size,"strip scale per row",stats)
bg=Image.new("RGBA",sheet.size,(28,28,36,255)); bg.alpha_composite(sheet)
bg.resize((sheet.size[0]*4,sheet.size[1]*4),Image.NEAREST).save("prev_player.png")
bg.crop((0,0,8*FW,64)).resize((8*FW*7,64*7),Image.NEAREST).save("prev_player_zoom.png")
