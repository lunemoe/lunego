import subprocess, concurrent.futures as cf, os
P={
 "ui_panel": ("pixel art game UI window frame, empty rectangular ornate dark stone and gold dialog panel, thick 4 pixel border with gold corner studs, flat dark navy interior, 9-slice friendly: uniform straight edges and symmetric corners, crisp pixels, no text, no contents, front view", False),
 "ui_button": ("pixel art game UI button, empty rectangular button plate of dark grey stone with gold trim and beveled edge, 9-slice friendly uniform edges, crisp pixels, no text, front view", False),
 "tile_wall_top": ("pixel art game tile, seamless top of a dungeon stone wall seen from above, dark grey blocks with moss, tileable, crisp pixels, limited palette, flat orthographic", False),
}
def run(kv):
    n,(p,_)=kv; f=f"raw/{n}.png"
    if os.path.exists(f) and os.path.getsize(f)>1000: return n,"cached"
    r=subprocess.run(["gpt-image",p,"--background","transparent","-a","square","-o",f,"-q"],capture_output=True,text=True)
    return n, "ok" if r.returncode==0 and os.path.exists(f) else "FAIL "+r.stderr[-200:]
with cf.ThreadPoolExecutor(3) as ex:
    for n,s in ex.map(run,P.items()): print(n,s,flush=True)
