"""Projectiles (16px), item icons (24px) and UI icon rows (16px) from raw/*.png."""
import sys; sys.path.insert(0,'.')
import pixel
from PIL import Image

def cell(src, n, size, pad=1):
    fr=pixel.frames_to_img(pixel.split_strip(pixel.load_rgba(src), n))
    out=[]
    for im in fr:
        w,h=im.size; s=min((size-2*pad)/w,(size-2*pad)/h)
        c=pixel.cleanup(pixel.quantize(im.resize((max(1,round(w*s)),max(1,round(h*s))),Image.LANCZOS)))
        cv=Image.new("RGBA",(size,size),(0,0,0,0)); cv.paste(c,((size-c.size[0])//2,size-pad-c.size[1])); out.append(cv)
    return out

for k in ("arrow","bolt","fire"):
    c=cell(f"raw/proj_{k}.png",1,16,1)[0]; c.save(f"../sprites/projectiles/{k}.png")

ITEMS=[("coin","coin"),("gem","gem"),("chest","chest"),("chest_open","chest_open"),("potion","potion"),
       ("sword","sword"),("armor","armor"),("amulet","amulet"),("runestone","runestone")]
atlas=Image.new("RGBA",(len(ITEMS)*24,24),(0,0,0,0))
for i,(src,name) in enumerate(ITEMS):
    c=cell(f"raw/item_{src}.png",1,24,1)[0]; c.save(f"../sprites/items/{name}.png"); atlas.paste(c,(i*24,0))
atlas.save("../sprites/items/items.png")

icons=[]
for src,n in (("ui_icons",6),("ui_icons2",5)):
    icons += cell(f"raw/{src}.png",n,16,1)
sheet=Image.new("RGBA",(16*len(icons),16),(0,0,0,0))
for i,c in enumerate(icons): sheet.paste(c,(i*16,0))
sheet.save("../sprites/ui/icons.png")
print("items/projectiles/icons rebuilt:", len(icons), "icons")
