import subprocess, concurrent.futures as cf, os, json, sys
OUT="raw"; os.makedirs(OUT, exist_ok=True)
BASE="pixel art game sprite, crisp hard pixel edges, flat colors, thick dark outline, limited 16 color palette, no text, no background scenery"
P={
 "player_walk_down": "pixel art game sprite sheet, ONE character, exactly 4 frame walk cycle laid out in a single horizontal row, hero knight in blue tabard with sword and round shield seen from the FRONT facing the camera in top-down 3/4 view, evenly spaced frames, identical character design scale and pose baseline in every frame, only legs and cape change between frames",
 "player_walk_up": "pixel art game sprite sheet, ONE character, exactly 4 frame walk cycle laid out in a single horizontal row, the SAME hero knight in blue tabard with sword and round shield seen from BEHIND, back of helmet and cape, walking away from the camera in top-down 3/4 view, evenly spaced frames, identical character design and scale in every frame",
 "player_walk_side": "pixel art game sprite sheet, ONE character, exactly 4 frame walk cycle laid out in a single horizontal row, the SAME hero knight in blue tabard with sword and round shield seen in right-facing PROFILE, walking toward the right side of the image, top-down 3/4 view, evenly spaced frames, identical character design and scale in every frame",
 "player_attack_down": "pixel art game sprite sheet, ONE character, exactly 3 frame sword attack animation laid out in a single horizontal row, hero knight in blue tabard swinging a sword forward toward the FRONT of the camera, top-down 3/4 view, evenly spaced frames, identical character design and scale, frame1 wind up, frame2 full swing, frame3 recovery",
 "player_attack_up": "pixel art game sprite sheet, ONE character, exactly 3 frame sword attack animation laid out in a single horizontal row, hero knight seen from BEHIND swinging sword upward away from the camera, top-down 3/4 view, evenly spaced frames, identical character design and scale",
 "player_attack_side": "pixel art game sprite sheet, ONE character, exactly 3 frame sword attack animation laid out in a single horizontal row, hero knight in right-facing PROFILE thrusting a sword to the right, top-down 3/4 view, evenly spaced frames, identical character design and scale",
 "slime_walk": "pixel art game sprite sheet, ONE creature, exactly 4 frame bounce animation laid out in a single horizontal row, small translucent lime green slime blob with two dark round eyes and a glossy highlight, top-down 3/4 view, squashing and stretching between frames, identical design and scale",
 "brute_walk": "pixel art game sprite sheet, ONE creature, exactly 4 frame heavy walk animation laid out in a single horizontal row, hulking red skinned brute demon with iron shoulder plates and a huge cleaver axe, facing the camera in top-down 3/4 view, identical design and scale",
 "ranged_walk": "pixel art game sprite sheet, ONE creature, exactly 4 frame floating walk animation laid out in a single horizontal row, hooded purple cultist mage holding a glowing cyan orb staff, floating slightly above the ground, facing the camera in top-down 3/4 view, identical design and scale",
 "charger_walk": "pixel art game sprite sheet, ONE creature, exactly 4 frame galloping run animation laid out in a single horizontal row, armored tusked boar beast with rusty iron plates charging toward the right, top-down 3/4 view, identical design and scale",
 "bomber_walk": "pixel art game sprite sheet, ONE creature, exactly 4 frame waddling animation laid out in a single horizontal row, round bomb creature with a lit fuse, stubby legs, angry eyes, dark metal body with orange glowing cracks, facing the camera in top-down 3/4 view, identical design and scale",
 "elite_walk": "pixel art game sprite sheet, ONE creature, exactly 4 frame menacing walk animation laid out in a single horizontal row, elite armored dark knight with glowing violet runes on black plate armor and a horned helmet, bigger and more ornate than a normal knight, facing the camera in top-down 3/4 view, identical design and scale",
 "proj_arrow": "pixel art game projectile, ONE small wooden arrow with steel tip flying to the right, side view, crisp pixels, transparent background, centered, tiny object",
 "proj_bolt": "pixel art game projectile, ONE small glowing cyan magic bolt with sparkle trail pointing to the right, crisp pixels, transparent background, centered, tiny object",
 "proj_fire": "pixel art game projectile, ONE small orange fireball with flame tail pointing to the right, crisp pixels, transparent background, centered, tiny object",
 "item_coin": "pixel art game item, ONE single shiny gold coin with a crown emblem, three quarter view, crisp pixels, transparent background, centered, tiny object",
 "item_gem": "pixel art game item, ONE single faceted blue sapphire gem, three quarter view, crisp pixels, transparent background, centered, tiny object",
 "item_chest": "pixel art game sprite, ONE closed wooden treasure chest with iron bands and gold lock, top-down 3/4 view, crisp pixels, transparent background, centered",
 "item_chest_open": "pixel art game sprite, ONE open wooden treasure chest with gold coins spilling out and a glowing interior, top-down 3/4 view, crisp pixels, transparent background, centered",
 "item_potion": "pixel art game item, ONE red healing potion flask with cork, crisp pixels, transparent background, centered, tiny object",
 "tile_floor_stone": "pixel art seamless dungeon stone floor tile, flat top-down view, grey flagstones with small cracks, NO perspective, tileable, crisp pixels, limited palette",
 "tile_floor_dirt": "pixel art seamless cracked earth dirt floor tile, flat top-down view, brown soil with pebbles, NO perspective, tileable, crisp pixels, limited palette",
 "tile_wall_stone": "pixel art seamless dungeon wall tile, flat top-down view of a stone brick wall, dark grey blocks with moss in the mortar, tileable, crisp pixels, limited palette",
 "tile_decor_torch": "pixel art game sprite, ONE wall torch with burning flame on a small stone bracket, transparent background, centered, crisp pixels",
 "ui_icons": "pixel art game UI icon sheet, exactly 6 icons in a single horizontal row evenly spaced on a transparent background: red heart, steel sword, gold coin, blue gem, white skull, golden star; flat colors, thick dark outline, crisp pixels, no text, each icon centered in its own cell",
}
ok={}; bad={}
def run(kv):
    n,p=kv; f=f"{OUT}/{n}.png"
    if os.path.exists(f) and os.path.getsize(f)>1000: return n,"cached"
    r=subprocess.run(["gpt-image", p+BASE, "--background","transparent","-a","wide" if n in("ui_icons",) or "walk" in n or "attack" in n else "square","-o",f,"-q"],capture_output=True,text=True)
    if r.returncode!=0 or not os.path.exists(f): return n,"FAIL "+r.stderr[-300:]
    return n,"ok"
with cf.ThreadPoolExecutor(6) as ex:
    for n,s in ex.map(run,P.items()):
        print(n,s,flush=True)
