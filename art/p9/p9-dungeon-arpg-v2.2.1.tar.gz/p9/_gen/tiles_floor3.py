"""Toroidal Voronoi cobblestone floor: seamless, organic stones, shared palette."""
from PIL import Image
import numpy as np, random
S=32
OUT="/home/zero/Documents/lunego-workspace/games/p9/assets/tiles"
INK=(26,26,38); DARK=(46,47,61)

def voronoi(seed, sites_n, tones, grout=DARK, speck=14, moss=False):
    r=random.Random(seed)
    sites=[(r.uniform(0,S), r.uniform(0,S), r.choice(tones)) for _ in range(sites_n)]
    a=np.zeros((S,S,4),np.uint8); a[:,:,3]=255
    for y in range(S):
        for x in range(S):
            ds=[]
            for (sx,sy,c) in sites:
                dx=abs(x-sx); dy=abs(y-sy)
                dx=min(dx,S-dx); dy=min(dy,S-dy)          # torus -> seamless
                ds.append((dx*dx+dy*dy, c))
            ds.sort()
            d1,c1=ds[0]; d2,_=ds[1]
            if np.sqrt(d2)-np.sqrt(d1) < 1.5: a[y,x]=(*grout,255)
            else:
                # subtle lighting: lighter toward upper-left within each stone
                a[y,x]=(*c1,255)
    # stone interior shading: light top edge pixels / dark bottom
    for y in range(S):
        for x in range(S):
            if tuple(a[y,x,:3])==grout: continue
            up=tuple(a[(y-1)%S,x,:3]); dn=tuple(a[(y+1)%S,x,:3])
            ul=tuple(a[(y-1)%S,(x-1)%S,:3]); ur=tuple(a[(y-1)%S,(x+1)%S,:3])
            dl=tuple(a[(y+1)%S,(x-1)%S,:3]); dr=tuple(a[(y+1)%S,(x+1)%S,:3])
            if up==grout and ul==grout and ur==grout: a[y,x]=(*tones[-1],255)
            elif dn==grout and dl==grout and dr==grout: a[y,x]=(*tones[0],255)
    for _ in range(speck):
        x,y=r.randrange(S),r.randrange(S)
        if tuple(a[y,x,:3])==grout: continue
        a[y,x]=(*r.choice([DARK, tones[1], tones[2]]),255)
    if moss:
        for _ in range(6):
            x,y=r.randrange(S),r.randrange(S)
            if tuple(a[y,x,:3])!=grout: a[y,x]=(*r.choice([(42,102,56),(79,166,74)]),255)
    return a

STONE_TONES=[(58,60,74),(74,76,94),(88,91,110),(107,110,130)]
DIRT_TONES=[(58,38,26),(78,50,32),(94,62,36),(112,76,44)]
for i,(seed,n) in enumerate(((11,10),(29,11),(47,9))):
    Image.fromarray(voronoi(seed,n,STONE_TONES,moss=(i==1)),"RGBA").save(f"{OUT}/floor_stone_{chr(97+i)}.png")
Image.fromarray(voronoi(11,6,STONE_TONES),"RGBA").save(f"{OUT}/floor_stone.png")
Image.fromarray(voronoi(61,6,DIRT_TONES,grout=(40,26,18),speck=18),"RGBA").save(f"{OUT}/floor_dirt.png")
print("ok")
