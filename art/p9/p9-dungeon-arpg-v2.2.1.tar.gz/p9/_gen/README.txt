Asset generation pipeline (not shipped at runtime).

gen.py gen2.py gen3.py gen4.py   text prompts -> raw/*.png via gpt-image-2.5 (transparent)
restyle.py restyle2.py           image-to-image "redraw as clean low-res pixel art" pass for detailed strips
pixel.py                         alpha-aware strip splitting, palette quantise (28 colours), cleanup, outline
build_player.py                  4 rows (down/left/right/up) x 18 cols spritesheet
build_enemies.py                 enemy sheets 32/40/64 px
build_ui.py                      nine-slice panel/button sources
build_items.py                   projectiles, item icons, UI icon rows
tiles_proc.py tiles_floor3.py    procedural 32px dungeon tiles (toroidal Voronoi floors)
build_manifest.py                regenerates manifest.json
build_preview.py                 contact sheet preview.png
Run order: gen* -> restyle* -> build_player / build_enemies / build_items / build_ui / tiles* -> build_manifest -> build_preview
raw/ is deleted after shipping; re-run the gen scripts to recreate it (prompts are the source of truth).
