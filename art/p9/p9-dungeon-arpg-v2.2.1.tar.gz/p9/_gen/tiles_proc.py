"""Deterministic 32x32 dungeon tileset, drawn natively in the shared palette (no downscaling)."""
from PIL import Image
import numpy as np, random

OUT="/home/zero/Documents/lunego-workspace/games/p9/assets/tiles"
S=32
C=dict(o=(16,16,24), ink=(26,26,38), dark=(46,47,61), stone=(74,76,94), stone_l=(107,110,130),
       stone_h=(154,157,178), white=(232,236,244), wood=(138,90,51), wood_d=(78,50,32),
       wood_l=(176,124,42), gold=(242,193,78), gold_d=(176,124,42), moss=(42,102,56),
       moss_l=(79,166,74), red=(200,57,43), bone=(216,203,168))

def blank(fill=None):
    a=np.zeros((S,S,4),np.uint8)
    if fill: a[:,:]=(*fill,255)
    return a

def put(a,x,y,c,al=255):
    x%=S; y%=S
    a[y,x]=(*c,al)

def rect(a,x0,y0,x1,y1,c):
    for y in range(y0,y1+1):
        for x in range(x0,x1+1): put(a,x,y,c)

def save(a,name):
    Image.fromarray(a,"RGBA").save(f"{OUT}/{name}.png")

def rng(seed): return random.Random(seed)

# ---------- floors ----------
def floor_stone():
    a=blank(C["stone"])
    r=rng(7)
    # 2x2 slabs, grout on the wrap lines
    for sy in range(0,S,16):
        for sx in range(0,S,16):
            # slab bevel
            for x in range(sx+1,sx+16):
                put(a,x,sy+1,C["stone_l"])
                put(a,x,sy+15,C["dark"])
            for y in range(sy+1,sy+16):
                put(a,sx+1,y,C["stone_l"])
                put(a,sx+15,y,C["dark"])
    for x in range(S): put(a,x,0,C["dark"]); put(a,x,16,C["dark"])
    for y in range(S): put(a,0,y,C["dark"]); put(a,16,y,C["dark"])
    # speckles + chips inside slabs
    for _ in range(46):
        x,y=r.randrange(S),r.randrange(S)
        if x%16 in (0,15) or y%16 in (0,15): continue
        put(a,x,y,r.choice([C["dark"],C["stone_l"],C["stone"]]))
    # a crack
    for i,(x,y) in enumerate([(22,6),(23,7),(23,8),(24,9),(24,10),(25,11)]): put(a,x,y,C["ink"])
    return a

def floor_dirt():
    a=blank(C["wood_d"])
    r=rng(11)
    for _ in range(150):
        x,y=r.randrange(S),r.randrange(S)
        put(a,x,y,r.choice([(58,38,26),C["wood"],(94,62,36),(46,32,22)]))
    for (x,y) in [(5,7),(6,7),(7,8),(18,22),(19,22),(20,23),(12,26)]:
        put(a,x,y,(120,110,100)); put(a,(x+1)%S,y,(92,84,78))
    return a

def wall_stone():
    a=blank(C["stone"]); r=rng(13)
    for y in range(0,S,8):                 # mortar rows
        for x in range(S): put(a,x,y,C["ink"])
    for row,y0 in enumerate(range(0,S,8)):
        off = 0 if row%2==0 else 8
        for x in range(off,S+off,16):       # vertical joints every 16px, wrapped
            for y in range(y0+1,y0+8): put(a,x%S,y,C["ink"])
        # brick bevel
        for x in range(S):
            if (x-off)%16==0: continue
            put(a,x,y0+1,C["stone_l"])
            put(a,x,y0+7,C["dark"])
    for _ in range(20):                      # weathering
        x,y=r.randrange(S),r.randrange(S)
        if y%8==0: continue
        put(a,x,y,r.choice([C["dark"],C["stone_l"]]))
    for (x,y) in [(3,3),(4,3),(3,4),(20,18),(21,18),(21,19)]: put(a,x,y,C["moss"])
    return a

def wall_top():
    a=wall_stone()
    m=np.array(a)
    dark=np.array([*C["ink"],255]); d2=np.array([*C["dark"],255])
    m[:,:] = (m*0.55).astype(np.uint8)
    m[:,:,3]=255
    for x in range(S): m[0,x]=dark; m[S-1,x]=d2
    return m

def door_closed():
    a=blank(C["dark"])
    # stone frame
    rect(a,0,0,S-1,S-1,C["stone"])
    rect(a,1,1,S-2,S-2,C["stone_l"])
    # door leaf
    rect(a,4,4,S-5,S-3,C["wood"])
    for x in range(6,S-5,5):
        for y in range(4,S-3): put(a,x,y,C["wood_d"])
    for y in (9,20):                      # iron bands
        rect(a,4,y,S-5,y,C["stone_h"]); rect(a,4,y+1,S-5,y+1,C["dark"])
    rect(a,22,14,24,16,C["gold"]); put(a,23,15,C["gold_d"])
    rect(a,0,0,S-1,2,C["stone_h"])        # top highlight
    rect(a,0,S-3,S-1,S-1,C["ink"])
    return a

def door_open():
    a=blank(C["ink"])
    rect(a,0,0,S-1,S-1,C["stone"])
    rect(a,1,1,S-2,S-2,C["stone_l"])
    rect(a,4,4,S-5,S-3,C["ink"])
    for y in range(4,S-3,6):               # portcullis bars raised
        rect(a,4,y,S-5,y,C["dark"])
    rect(a,14,4,17,S-4,C["dark"]); rect(a,14,4,14,S-4,C["stone"])
    rect(a,0,0,S-1,2,C["stone_h"]); rect(a,0,S-3,S-1,S-1,C["ink"])
    return a

def stairs_down():
    a=blank(C["stone"])
    steps=4; h=S//steps
    for i in range(steps):
        y0=i*h
        shade=[C["stone_l"],C["stone"],C["dark"],C["ink"]][min(i,3)]
        rect(a,0,y0,S-1,y0+h-1,shade)
        rect(a,0,y0,S-1,y0,C["stone_h"] if i<2 else C["dark"])
        inset=i*2
        rect(a,0,y0+h-1,S-1,y0+h-1,C["ink"])
        for x in range(S): 
            put(a,x,y0+h-1,C["ink"])
        rect(a,0,y0,inset,y0+h-1,C["dark"]); rect(a,S-1-inset,y0,S-1,y0+h-1,C["dark"])
    return a

# ---------- props (transparent) ----------
def crate():
    a=blank(None)
    x0,y0,x1,y1=3,4,27,29
    rect(a,x0,y0,x1,y1,C["wood"])
    rect(a,x0,y0,x1,y0+1,C["wood_l"])
    for x in range(x0,x1+1,6):
        rect(a,x,y0,x,y1,C["wood_d"])
    rect(a,x0,y0,x0+1,y1,C["wood_d"]); rect(a,x1-1,y0,x1,y1,C["wood_d"])
    rect(a,x0,y1-1,x1,y1,C["ink"]); rect(a,x1,y0,x1,y1,C["ink"])
    for i in range(0,22):                 # top plank highlight
        put(a,x0+2+i,y0+2,C["wood_l"])
    for i in range(2,20):                 # bottom shadow
        put(a,x0+2+i,y1-2,C["wood_d"])
    return a

def barrel():
    a=blank(None)
    cx=16
    for y in range(6,29):
        w=10 if 12<=y<=22 else 8
        for x in range(cx-w,cx+w+1):
            t=(x-(cx-w))/(2*w)
            c=C["wood_l"] if t<0.25 else C["wood_d"] if t>0.8 else C["wood"]
            put(a,x,y,c)
    for y in (9,17,25):
        for x in range(cx-9,cx+10): put(a,x,y,C["dark"]); put(a,x,y+1,C["dark"])
    rect(a,cx-2,6,cx+2,6,C["wood_l"])
    rect(a,cx-10,28,cx+10,28,C["ink"])
    return a

def pillar():
    a=blank(None)
    rect(a,9,2,22,29,C["stone"])
    rect(a,9,2,10,29,C["stone_l"])
    rect(a,21,2,22,29,C["dark"])
    rect(a,6,2,25,5,C["stone_l"])     # capital
    rect(a,6,2,25,3,C["stone_h"])
    rect(a,6,26,25,29,C["dark"])      # base
    for y in range(6,26,6): rect(a,11,y,20,y,C["dark"])
    return a

def torch(flicker=0):
    a=blank(None)
    rect(a,14,16,17,29,C["wood_d"])          # bracket
    rect(a,13,18,18,20,C["stone_h"])
    rect(a,13,19,18,20,C["dark"])
    base_y=15-flicker
    for y in range(base_y-6,base_y+1):       # flame
        w=3-abs(y-(base_y-2))//2
        for x in range(16-w,16+w+1):
            put(a,x,y,C["gold"] if abs(x-16)<=w-1 else C["wood_l"])
    rect(a,15,base_y+1,17,base_y+2,(232,116,58))
    put(a,16,base_y-6,C["white"])
    return a

if __name__=="__main__":
    save(floor_stone(),"floor_stone"); save(floor_dirt(),"floor_dirt")
    save(wall_stone(),"wall_stone"); save(wall_top(),"wall_top")
    save(door_closed(),"door_closed"); save(door_open(),"door_open")
    save(stairs_down(),"stairs_down")
    save(crate(),"crate"); save(barrel(),"barrel"); save(pillar(),"pillar")
    Image.fromarray(np.vstack([torch(0),torch(1)]),"RGBA").save(f"{OUT}/torch.png")
    print("tiles written")
