#!/usr/bin/env python3
"""Validate the p9 runtime asset pack against manifest.json."""
import json, os, subprocess, sys
from PIL import Image
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
errors, warnings, checked = [], [], 0

def err(m): errors.append(m)
def warn(m): warnings.append(m)

man = json.load(open(os.path.join(ROOT, "manifest.json")))
print(f"manifest: {man['pack']} v{man['version']}  assets={len(man['assets'])} audio={len(man['audio'])}")

def check_png(entry):
    global checked
    path = os.path.join(ROOT, entry["file"])
    if not os.path.exists(path):
        err(f"{entry['id']}: missing file {entry['file']}"); return None
    try:
        im = Image.open(path); im.load()
    except Exception as e:
        err(f"{entry['id']}: unreadable PNG ({e})"); return None
    if im.mode != "RGBA":
        err(f"{entry['id']}: mode {im.mode}, expected RGBA"); return None
    w, h = im.size
    fw, fh = entry["frameWidth"], entry["frameHeight"]
    cols, rows = entry["columns"], entry["rows"]
    if (w, h) != (fw * cols, fh * rows):
        err(f"{entry['id']}: {w}x{h} != {cols}x{rows} frames of {fw}x{fh}")
    if entry.get("frames") != cols * rows:
        err(f"{entry['id']}: frames field {entry.get('frames')} != {cols*rows}")
    a = np.array(im); alpha = a[..., 3]
    if entry.get("transparent", True):
        if alpha.max() == 0:
            err(f"{entry['id']}: fully transparent")
        declared = set()
        row_anims = {an.get("row"): an for an in entry.get("animations", []) if "row" in an}
        if entry.get("type") in ("atlas", "tileset-atlas") and entry.get("columnOrder"):
            # Sparse atlases may leave trailing cells unused; only listed frames must be non-empty.
            declared = {(i // cols, i % cols) for i in range(len(entry["columnOrder"]))}
        elif row_anims:
            for r, an in row_anims.items():
                c0, c1 = an["columns"]
                for c in range(c0, c1 + 1):
                    declared.add((r, c))
        else:
            declared = {(f // cols, f % cols) for f in range(cols * rows)}
        for r, c in declared:
            if not (alpha[r*fh:(r+1)*fh, c*fw:(c+1)*fw] > 0).any():
                err(f"{entry['id']}: empty frame row{r} col{c}")
        semi = int(((alpha > 0) & (alpha < 255)).sum())
        if semi:
            warn(f"{entry['id']}: {semi} semi-transparent pixels")
    rgb = a[..., :3][alpha > 0]
    colours = len(np.unique(rgb.reshape(-1, 3), axis=0)) if rgb.size else 0
    if colours > 48:
        err(f"{entry['id']}: {colours} unique colours (palette discipline broken)")
    for anim in entry.get("animations", []):
        if "columns" in anim:
            c0, c1 = anim["columns"]
            if not (0 <= c0 <= c1 < cols):
                err(f"{entry['id']}.{anim['name']}: columns {c0}-{c1} outside 0-{cols-1}")
            if anim.get("frames") != c1 - c0 + 1:
                err(f"{entry['id']}.{anim['name']}: frames {anim.get('frames')} != {c1-c0+1}")
        if "row" in anim and not (0 <= anim["row"] < rows):
            err(f"{entry['id']}.{anim['name']}: row {anim['row']} outside 0-{rows-1}")
        if "rows" in anim:
            r0, r1 = anim["rows"]
            if not (0 <= r0 <= r1 < rows):
                err(f"{entry['id']}.{anim['name']}: rows {r0}-{r1} outside 0-{rows-1}")
    if entry.get("type") == "nine-slice":
        border = entry.get("nineSlice", {}).get("border")
        if not border or border * 2 >= min(fw, fh):
            err(f"{entry['id']}: bad nine-slice border {border}")
    checked += 1
    return colours

colour_report = {}
for e in man["assets"]:
    c = check_png(e)
    if c is not None:
        colour_report[e["id"]] = c

# Tile seam continuity only for standalone 32px opaque tiles.
for e in man["assets"]:
    if not e.get("tags") or "tile" not in e["tags"] or e["file"].endswith("tileset.png"):
        continue
    if e.get("seamless") is False:
        continue
    if "door" in e["id"] or "stairs" in e["id"]:
        continue
    a = np.array(Image.open(os.path.join(ROOT, e["file"])).convert("RGBA"))
    if a.shape[:2] != (32, 32) or e.get("transparent", True):
        continue
    rgb = a[..., :3].astype(int)
    wrap = (np.abs(rgb[:, 0] - rgb[:, -1]).mean() + np.abs(rgb[0, :] - rgb[-1, :]).mean()) / 2
    inner = (np.abs(rgb[:, 15] - rgb[:, 16]).mean() + np.abs(rgb[15, :] - rgb[16, :]).mean()) / 2
    if wrap > inner * 2.5 + 2:
        err(f"{e['id']}: seam discontinuity wrap={wrap:.1f} vs interior={inner:.1f}")

for e in man["audio"]:
    p = os.path.join(ROOT, e["file"])
    if not os.path.exists(p):
        err(f"{e['id']}: missing {e['file']}"); continue
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration:stream=codec_name,channels",
                        "-of", "json", p], capture_output=True, text=True)
    if r.returncode != 0:
        err(f"{e['id']}: ffprobe failed"); continue
    info = json.loads(r.stdout)
    dur = float(info["format"]["duration"])
    if dur <= 0:
        err(f"{e['id']}: duration {dur}")
    if abs(dur - e["duration"]) > 0.1:
        warn(f"{e['id']}: manifest duration {e['duration']} != file {dur:.3f}")
    st = info["streams"][0]
    if st.get("codec_name") != "vorbis":
        err(f"{e['id']}: codec {st.get('codec_name')} not vorbis")
    if e.get("loop") and dur < e.get("minDuration", 0):
        err(f"{e['id']}: loop shorter than {e.get('minDuration')}s")
    checked += 1

for e in man["assets"] + man["audio"]:
    src = e.get("source") or {}
    if not src.get("license"):
        err(f"{e['id']}: missing source.license")
    if not src.get("kind"):
        err(f"{e['id']}: missing source.kind")

print("colour counts:", ", ".join(f"{k}={v}" for k, v in sorted(colour_report.items(), key=lambda kv: -kv[1])[:6]), "...")
for w in warnings: print("WARN ", w)
for e in errors: print("FAIL ", e)
print(f"checked {checked} files, {len(warnings)} warnings, {len(errors)} errors")
sys.exit(1 if errors else 0)
